const fs = require('fs');
const zlib = require('zlib');

function makePNG(width, height, getPixel) {
  const rowSize = width * 4 + 1;
  const raw = Buffer.alloc(rowSize * height);
  for (let y = 0; y < height; y++) {
    const rowOffset = y * rowSize;
    raw[rowOffset] = 0; // Filter None
    for (let x = 0; x < width; x++) {
      const [r, g, b, a] = getPixel(x, y);
      const pxOffset = rowOffset + 1 + x * 4;
      raw[pxOffset] = r;
      raw[pxOffset + 1] = g;
      raw[pxOffset + 2] = b;
      raw[pxOffset + 3] = a;
    }
  }
  const compressed = zlib.deflateSync(raw);

  function crc32(buf) {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc ^= buf[i];
      for (let j = 0; j < 8; j++) {
        crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
      }
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  function chunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const typeBuf = Buffer.from(type, 'binary');
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])));
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    sig,
    chunk('IHDR', ihdr),
    chunk('IDAT', compressed),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

// 1. Generate 11.png (Dotted World Map - Transparent PNG, 1000x500)
console.log('Generating public/11.png (Dotted World Map)...');
const w1 = 1000;
const h1 = 500;
const step = 10;
const dotRadius = 2.4;

// Polygonal rough shapes for world continents normalized 0..1000, 0..500
function isLand(gx, gy) {
  // North America
  if (gx >= 50 && gx <= 290 && gy >= 50 && gy <= 250) {
    if (gx <= 120 && gy >= 200) return false;
    if (gx >= 260 && gy >= 200 && gx > 240 + (gy - 200) * 1.5) return false;
    return true;
  }
  // Central America
  if (gx >= 160 && gx <= 270 && gy >= 230 && gy <= 300) {
    const cy = 230 + (gx - 160) * 0.7;
    return Math.abs(gy - cy) < 22;
  }
  // South America
  if (gx >= 240 && gx <= 360 && gy >= 270 && gy <= 470) {
    if (gy > 420 && gx > 310) return false;
    if (gx < 270 && gy > 350 && gx < 240 + (gy - 350) * 0.4) return false;
    return true;
  }
  // Europe
  if (gx >= 450 && gx <= 580 && gy >= 80 && gy <= 230) {
    if (gx < 480 && gy < 140 && !(gx >= 460 && gx <= 485 && gy >= 100 && gy <= 140)) return false; // Scandinavia / UK
    return true;
  }
  // Africa
  if (gx >= 440 && gx <= 600 && gy >= 200 && gy <= 420) {
    if (gx < 470 && gy > 330) return false;
    if (gx > 540 && gy > 380) return false;
    return true;
  }
  // Asia
  if (gx >= 550 && gx <= 890 && gy >= 70 && gy <= 320) {
    if (gx < 630 && gy > 280) return false; // Arabian Sea
    if (gx >= 650 && gx <= 750 && gy > 280) return true; // India
    if (gx > 850 && gy > 260) return false;
    return true;
  }
  // Southeast Asia & Indonesia
  if (gx >= 730 && gx <= 840 && gy >= 300 && gy <= 400) {
    if (Math.sin(gx * 0.1) * Math.cos(gy * 0.1) > -0.2) return true;
  }
  // Japan
  if (gx >= 840 && gx <= 880 && gy >= 160 && gy <= 230) {
    const slope = (gx - 840) * 1.5 + 160;
    return Math.abs(gy - slope) < 18;
  }
  // Australia
  if (gx >= 760 && gx <= 900 && gy >= 350 && gy <= 460) {
    if (gx < 780 && gy > 420) return false;
    if (gx > 880 && gy < 380) return false;
    return true;
  }
  // New Zealand
  if (gx >= 910 && gx <= 940 && gy >= 420 && gy <= 470) return true;

  return false;
}

// Precompute dots
const dots = [];
for (let gx = 40; gx <= 960; gx += step) {
  for (let gy = 40; gy <= 470; gy += step) {
    if (isLand(gx, gy)) {
      dots.push({ x: gx, y: gy });
    }
  }
}

const mapPNG = makePNG(w1, h1, (x, y) => {
  // Check distance to closest dot
  const gridX = Math.round(x / step) * step;
  const gridY = Math.round(y / step) * step;
  const dist = Math.hypot(x - gridX, y - gridY);

  if (dist <= dotRadius && isLand(gridX, gridY)) {
    const alpha = Math.max(0, Math.min(255, Math.round((1 - dist / dotRadius) * 230 + 25)));
    return [205, 220, 235, alpha];
  }
  return [0, 0, 0, 0];
});
fs.writeFileSync('public/11.png', mapPNG);
console.log('Saved public/11.png, size:', mapPNG.length);

// 2. Generate 22.png (Deep Space Earth Globe - 1280x720)
console.log('Generating public/22.png (Deep Space Cyber Earth)...');
const w2 = 1280;
const h2 = 720;
const cx = 1080;
const cy = 360;
const R = 440;

const spacePNG = makePNG(w2, h2, (x, y) => {
  const dist = Math.hypot(x - cx, y - cy);

  // Background deep space
  let r = 5;
  let g = 8;
  let b = 15;
  let a = 255;

  // Star speckles
  const hash = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
  if ((hash - Math.floor(hash)) > 0.996) {
    const starBright = Math.min(255, Math.floor(((hash - Math.floor(hash)) - 0.996) * 50000));
    r += starBright;
    g += starBright;
    b += starBright;
  }

  // Atmospheric halo glow
  if (dist >= R && dist <= R + 140) {
    const halo = 1 - (dist - R) / 140;
    const intensity = Math.pow(halo, 2.2);
    r = Math.min(255, Math.round(r + 14 * intensity));
    g = Math.min(255, Math.round(g + 165 * intensity));
    b = Math.min(255, Math.round(b + 255 * intensity));
  } else if (dist < R) {
    // Inside sphere of Earth
    const normDist = dist / R;
    const nx = (x - cx) / R;
    const ny = (y - cy) / R;
    const nz = Math.sqrt(Math.max(0, 1 - nx * nx - ny * ny));

    // Sun light direction (from upper right front: -0.6, -0.4, 0.7)
    const dot = -nx * 0.5 - ny * 0.4 + nz * 0.75;
    const light = Math.max(0.12, dot);

    // Oceanic deep cyan-blue base
    let baseR = 12;
    let baseG = 85;
    let baseB = 165;

    // Cyber grid lines on Earth
    const lat = Math.asin(ny) * 10;
    const lon = Math.atan2(nx, nz) * 10;
    const gridVal = Math.sin(lat) * Math.sin(lon);
    if (Math.abs(gridVal) < 0.1) {
      baseR = 40;
      baseG = 220;
      baseB = 255;
    }

    // Clouds / continents pattern
    const cloudNoise = Math.sin(nx * 8 + ny * 6) * Math.cos(ny * 9 - nx * 5);
    if (cloudNoise > 0.25) {
      baseR = Math.min(255, baseR + 130);
      baseG = Math.min(255, baseG + 150);
      baseB = Math.min(255, baseB + 160);
    }

    // Atmospheric rim glow inside border
    const rim = Math.pow(1 - nz, 3);
    r = Math.min(255, Math.round(baseR * light + 80 * rim));
    g = Math.min(255, Math.round(baseG * light + 200 * rim));
    b = Math.min(255, Math.round(baseB * light + 255 * rim));
  }

  return [r, g, b, a];
});
fs.writeFileSync('public/22.png', spacePNG);
console.log('Saved public/22.png, size:', spacePNG.length);
