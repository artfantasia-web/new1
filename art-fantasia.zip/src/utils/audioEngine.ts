/**
 * Web Audio API synthesizer engine for ArtFantasia audio portfolio playback.
 * Synthesizes musical textures and radio commercial tones smoothly in the browser.
 */

class AudioSynthesizer {
  private ctx: AudioContext | null = null;
  private isPlaying = false;
  private timerId: number | null = null;
  private masterGain: GainNode | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioContextClass();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.18, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public setVolume(vol: number) {
    if (this.masterGain && this.ctx) {
      const clamped = Math.max(0, Math.min(1, vol)) * 0.25;
      this.masterGain.gain.setValueAtTime(clamped, this.ctx.currentTime);
    }
  }

  public playTheme(theme: 'jingle' | 'corporate' | 'cinematic' | 'acoustic' | 'ambient') {
    this.stop();
    this.initContext();
    if (!this.ctx || !this.masterGain) return;

    this.isPlaying = true;

    const chords: Record<string, number[][]> = {
      jingle: [
        [523.25, 659.25, 783.99], // C5, E5, G5
        [587.33, 739.99, 880.00], // D5, F#5, A5
        [659.25, 830.61, 987.77], // E5, G#5, B5
        [783.99, 987.77, 1174.66] // G5, B5, D6
      ],
      corporate: [
        [440.00, 554.37, 659.25], // A4, C#5, E5
        [493.88, 622.25, 739.99], // B4, D#5, F#5
        [392.00, 493.88, 587.33], // G4, B4, D5
        [523.25, 659.25, 783.99]  // C5, E5, G5
      ],
      cinematic: [
        [220.00, 329.63, 440.00], // A3, E4, A4
        [261.63, 392.00, 523.25], // C4, G4, C5
        [293.66, 440.00, 587.33], // D4, A4, D5
        [329.63, 493.88, 659.25]  // E4, B4, E5
      ],
      acoustic: [
        [329.63, 392.00, 493.88], // E4, G4, B4
        [261.63, 329.63, 392.00], // C4, E4, G4
        [293.66, 369.99, 440.00], // D4, F#4, A4
        [392.00, 493.88, 587.33]  // G4, B4, D5
      ],
      ambient: [
        [261.63, 329.63, 523.25], // C4, E4, C5
        [349.23, 440.00, 698.46], // F4, A4, F5
        [392.00, 493.88, 783.99], // G4, B4, G5
        [329.63, 392.00, 659.25]  // E4, G4, E5
      ]
    };

    const noteProgression = chords[theme] || chords.jingle;
    let step = 0;

    const playChordStep = () => {
      if (!this.isPlaying || !this.ctx || !this.masterGain) return;

      const currentChord = noteProgression[step % noteProgression.length];
      const now = this.ctx.currentTime;

      currentChord.forEach((freq, idx) => {
        if (!this.ctx || !this.masterGain) return;
        const osc = this.ctx.createOscillator();
        const noteGain = this.ctx.createGain();

        // Waveform styling per theme
        osc.type = theme === 'cinematic' ? 'sawtooth' : theme === 'ambient' ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        // Envelope
        noteGain.gain.setValueAtTime(0.001, now + idx * 0.08);
        noteGain.gain.linearRampToValueAtTime(0.08, now + idx * 0.08 + 0.05);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

        osc.connect(noteGain);
        noteGain.connect(this.masterGain);

        osc.start(now + idx * 0.08);
        osc.stop(now + 1.3);
      });

      step++;
      this.timerId = window.setTimeout(playChordStep, 1100);
    };

    playChordStep();
  }

  public stop() {
    this.isPlaying = false;
    if (this.timerId !== null) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }
}

export const audioEngine = new AudioSynthesizer();
