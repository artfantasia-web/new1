import { useState } from 'react';
import { NavCategory } from './types';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { AboutSection } from './components/AboutSection';
import { VideoPortfolio } from './components/VideoPortfolio';
import { AudioPortfolio } from './components/AudioPortfolio';
import { MarketingSection } from './components/MarketingSection';
import { NoticeSection } from './components/NoticeSection';
import { AfanMusicSection } from './components/AfanMusicSection';
import { InquirySection } from './components/InquirySection';
import { Footer } from './components/Footer';
import { X } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState<NavCategory>('home');
  const [inquiryModalOpen, setInquiryModalOpen] = useState(false);

  // Switch to dedicated page view
  const handleNavigate = (section: NavCategory) => {
    setActiveSection(section);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#09090b] text-zinc-100 flex flex-col font-sans selection:bg-amber-400 selection:text-black">
      {/* 1. Global Header placed at the very top */}
      <Navbar
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenInquiry={() => handleNavigate('inquiry')}
      />

      {/* 2. Page View Router: Switches between dedicated pages */}
      <main className="flex-1">
        {activeSection === 'home' && (
          <Hero
            onExploreVideo={() => handleNavigate('video')}
            onExploreAudio={() => handleNavigate('audio')}
            onOpenInquiry={() => handleNavigate('inquiry')}
            onNavigate={handleNavigate}
          />
        )}

        {activeSection === 'about' && (
          <AboutSection onOpenInquiry={() => handleNavigate('inquiry')} />
        )}

        {activeSection === 'video' && (
          <VideoPortfolio onOpenInquiry={() => handleNavigate('inquiry')} />
        )}

        {activeSection === 'audio' && (
          <AudioPortfolio onOpenInquiry={() => handleNavigate('inquiry')} />
        )}

        {activeSection === 'afanmusic' && (
          <AfanMusicSection onOpenInquiry={() => handleNavigate('inquiry')} />
        )}

        {activeSection === 'marketing' && (
          <MarketingSection onOpenInquiry={() => handleNavigate('inquiry')} />
        )}

        {activeSection === 'notice' && (
          <NoticeSection />
        )}

        {activeSection === 'inquiry' && (
          <InquirySection />
        )}
      </main>

      {/* Global Project Inquiry Modal */}
      {inquiryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md">
          <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative text-zinc-900 border-0">
            <div className="sticky top-0 z-20 flex items-center justify-between p-4 sm:p-6 border-b border-zinc-100 bg-white/95 backdrop-blur-md">
              <div>
                <span className="text-xs font-mono text-amber-700 font-bold uppercase">
                  PROJECT INQUIRY // ART FANTASIA
                </span>
                <h3 className="text-lg font-bold text-zinc-900 mt-0.5">
                  프로젝트 제작 및 견적 문의
                </h3>
              </div>
              <button
                onClick={() => setInquiryModalOpen(false)}
                className="p-1.5 text-zinc-400 hover:text-zinc-900 rounded-lg hover:bg-zinc-100 transition-colors cursor-pointer"
                aria-label="닫기"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <InquirySection isModal onClose={() => setInquiryModalOpen(false)} />
          </div>
        </div>
      )}

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenInquiry={() => handleNavigate('inquiry')}
      />
    </div>
  );
}
