import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, Clapperboard, Film, Sparkles, Radio, ArrowRight, Building2, Tv, Music2, Headphones } from 'lucide-react';
import { MosaicLogo3D } from './MosaicLogo3D';
import { InternationalPortfolio } from './InternationalPortfolio';
import { CorporatePhilosophy } from './CorporatePhilosophy';
import { SectionEditorialHeader } from './SectionEditorialHeader';
import { NavCategory } from '../types';

interface HeroProps {
  onExploreVideo: () => void;
  onExploreAudio?: () => void;
  onOpenInquiry?: () => void;
  onNavigate?: (section: NavCategory) => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreVideo,
  onExploreAudio,
  onNavigate,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentTimeSec, setCurrentTimeSec] = useState(0);
  const [timecode, setTimecode] = useState('00:00:00:00');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const TOTAL_DURATION_SEC = 102; // 1분 42초

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = false;
    }
  }, []);

  // Translation detection for '아트판타지아가 걸어온 길.' -> 'PORTFOLIO'
  const [isTranslatedToEn, setIsTranslatedToEn] = useState(false);

  useEffect(() => {
    const checkTranslation = () => {
      const html = document.documentElement;
      const isEn =
        html.classList.contains('translated-ltr') ||
        html.classList.contains('translated-rtl') ||
        (html.getAttribute('lang') || '').toLowerCase().startsWith('en');
      setIsTranslatedToEn(isEn);
    };

    checkTranslation();

    const observer = new MutationObserver(() => {
      checkTranslation();
    });

    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class', 'lang'],
    });

    return () => observer.disconnect();
  }, []);

  // Video time update handler
  const handleTimeUpdate = () => {
    const video = videoRef.current;
    if (!video) return;
    const cur = video.currentTime;
    setCurrentTimeSec(cur);
    const dur = video.duration && !isNaN(video.duration) && video.duration > 0 ? video.duration : TOTAL_DURATION_SEC;
    setProgress((cur / dur) * 100);

    const m = Math.floor(cur / 60);
    const s = Math.floor(cur % 60);
    const f = Math.floor((cur % 1) * 30);
    const pad = (n: number) => n.toString().padStart(2, '0');
    setTimecode(`00:${pad(m)}:${pad(s)}:${pad(f)}`);
  };

  // Toggle video playback
  const togglePlay = (e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.muted = false;
      setIsMuted(false);
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
          })
          .catch((err) => {
            console.warn('Hero video play prevented, attempting fallback:', err);
            video.muted = true;
            setIsMuted(true);
            video.play().then(() => setIsPlaying(true)).catch(() => {});
          });
      }
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  // Toggle video mute/audio
  const toggleSound = () => {
    const video = videoRef.current;
    if (!video) return;
    const nextMuted = !isMuted;
    video.muted = nextMuted;
    setIsMuted(nextMuted);
    if (!nextMuted && video.paused) {
      video.play().catch(() => {});
      setIsPlaying(true);
    }
  };

  // Scrubber click handler
  const handleScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    if (!video) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const dur = video.duration && !isNaN(video.duration) && video.duration > 0 ? video.duration : TOTAL_DURATION_SEC;
    const targetTime = ratio * dur;
    video.currentTime = targetTime;
    setCurrentTimeSec(targetTime);
    setProgress(ratio * 100);
  };

  // Minimalist animated moving box shape (without logos or text)
  const renderMarqueeBox = (key: string | number) => (
    <div
      key={key}
      className="h-[38px] sm:h-[42px] min-w-[130px] sm:min-w-[155px] max-w-[210px] rounded-lg bg-zinc-950/85 border border-zinc-800/80 shadow-xs shrink-0 select-none"
    />
  );

  return (
    <section className="relative pt-3 sm:pt-4 pb-16 overflow-hidden border-b border-zinc-800 bg-[#09090b]">
      {/* Background Architectural Grid Pattern */}
      <div className="absolute inset-0 bg-grid-pattern pointer-events-none opacity-40" />

      <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">

        {/* Main Headline & Value Proposition Container with Animated Grid & Deep Vignette */}
        <div className="relative min-h-[calc(100vh-6.5rem)] py-12 sm:py-20 flex flex-col items-center justify-center text-center overflow-hidden rounded-2xl bg-zinc-950 my-2 sm:my-3 shadow-2xl">
          {/* Clearly Visible Animated Grid */}
          <div className="absolute inset-0 hero-animated-grid opacity-85 pointer-events-none" />

          {/* Animated Scanning Shimmer Beam */}
          <div className="absolute inset-x-0 h-44 bg-gradient-to-b from-transparent via-amber-400/15 to-transparent pointer-events-none animate-scanbeam" />

          {/* Deep Cinematic Vignette Layer */}
          <div className="absolute inset-0 hero-vignette pointer-events-none" />

          <div className="relative z-10 max-w-6xl w-full flex flex-col items-center justify-center text-center px-4 sm:px-6 my-auto">
            {/* Dazzling Mosaic Animated Logo */}
            <div className="mb-8 sm:mb-10 flex justify-center">
              <MosaicLogo3D size={270} />
            </div>

            <div
              className="inline-flex items-center gap-2.5 text-base sm:text-lg text-zinc-100 mb-6 px-6 py-2.5 rounded-full bg-zinc-900/95 border border-amber-400/30 shadow-xl opacity-0 animate-hero-reveal backdrop-blur-md"
              style={{ animationDelay: '100ms' }}
            >
              <Clapperboard className="w-5 h-5 text-amber-400 shrink-0" />
              <span className="font-['Noto_Sans_KR',sans-serif] font-bold tracking-tight text-white drop-shadow-sm">
                영상과 음악으로 만들어지는 여러분의 이야기
              </span>
            </div>
            <h1
              className="text-[26px] sm:text-[31px] md:text-[41px] lg:text-[51px] font-extrabold tracking-tight text-white leading-tight text-center opacity-0 animate-hero-reveal drop-shadow-[0_4px_24px_rgba(0,0,0,0.85)]"
              style={{ animationDelay: '250ms' }}
            >
              여러분의 이야기는 <span className="text-amber-400">특별</span>해야 합니다.
            </h1>
          </div>
        </div>

        {/* Nitex-style Interactive Showreel Container with Real Video */}
        <div className="relative rounded-lg border border-zinc-700/80 bg-zinc-950 overflow-hidden shadow-2xl">
          {/* Top Panel Bar */}
          <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900/90 border-b border-zinc-800 text-xs font-mono text-zinc-400">
            <div className="flex items-center gap-3">
              <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
              <span className="text-zinc-200 font-medium">ART FANTASIA SHOWREEL // 01:42</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="hidden sm:inline">CODEC: H.264 / PRORES</span>
              <span className="text-amber-400 tabular-nums">
                {timecode} <span className="text-zinc-500">/ 00:01:42:00</span>
              </span>
            </div>
          </div>

          {/* Video Player Screen */}
          <div className="relative aspect-video w-full overflow-hidden bg-black flex items-center justify-center group">
            <video
              ref={videoRef}
              src="https://res.cloudinary.com/iwcoiohr/video/upload/v1791867916/showreel.mp4"
              poster="/showreel_frame0.jpg?v=2"
              className="w-full h-full object-cover cursor-pointer"
              loop
              muted={isMuted}
              playsInline
              preload="metadata"
              onClick={togglePlay}
              onTimeUpdate={handleTimeUpdate}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
              onError={(e) => {
                // Fallback to primary CDN stream
                (e.currentTarget as HTMLVideoElement).src = 'https://res.cloudinary.com/iwcoiohr/video/upload/v1791867916/showreel.mp4';
              }}
            />

            {/* Cinematic Center Overlay & Play Button - Fixed on screen throughout video */}
            <div
              onClick={togglePlay}
              className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center cursor-pointer z-15 bg-black/15 hover:bg-black/25 transition-colors group/overlay"
            >
              <span className="text-xs sm:text-sm font-mono tracking-wider font-bold text-amber-400 uppercase mb-2 drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                Brand Film · TVC · Campaign Film · PSA · etc
              </span>
              <h2 className="text-lg sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-white tracking-tight drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)] uppercase mb-6">
                ART FANTASIA OFFICIAL SHOWREEL
              </h2>

              {/* Standard Gradient Play Button */}
              <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-r from-[#F15A29] via-[#E9422F] to-[#DD2426] text-white flex items-center justify-center shadow-[0_0_35px_rgba(233,66,47,0.6)] group-hover/overlay:scale-110 group-hover/overlay:shadow-[0_0_50px_rgba(233,66,47,0.85)] transition-all duration-300">
                <Play className="w-7 h-7 sm:w-9 sm:h-9 fill-white ml-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.3)]" />
              </div>

              <span className="text-xs sm:text-sm text-zinc-200 mt-4 font-medium drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                재생 버튼 또는 화면을 클릭하시면 영상을 감상하실 수 있습니다
              </span>
            </div>

            {/* Player Controls Overlay */}
            <div className="absolute bottom-2 sm:bottom-3 left-2 sm:left-4 right-2 sm:right-4 flex items-center justify-between gap-4 py-2 px-3.5 bg-black/80 backdrop-blur-md rounded border border-white/10 z-20">
              <div className="flex items-center gap-3">
                <button
                  onClick={togglePlay}
                  className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 cursor-pointer"
                  aria-label={isPlaying ? '일시 정지' : '재생'}
                >
                  {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
                </button>
                <button
                  onClick={toggleSound}
                  className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                  aria-label={isMuted ? '음소거 해제' : '음소거'}
                >
                  {isMuted ? <VolumeX className="w-4 h-4 text-zinc-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                  <span className="text-[11px] font-mono text-zinc-300 hidden sm:inline">
                    {isMuted ? 'MUTE' : 'AUDIO ON'}
                  </span>
                </button>
              </div>

              {/* Progress Bar & Time Scrubber */}
              <div className="flex-1 mx-2 flex items-center gap-3">
                <div
                  className="flex-1 h-1.5 bg-zinc-700/80 rounded overflow-hidden cursor-pointer relative"
                  onClick={handleScrub}
                >
                  <div
                    className="h-full bg-amber-400 transition-all duration-75"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <span className="text-xs font-mono text-zinc-300 tabular-nums">
                  {Math.floor(currentTimeSec / 60).toString().padStart(2, '0')}:
                  {Math.floor(currentTimeSec % 60).toString().padStart(2, '0')} / 01:42
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Corporate Philosophy: The 'A' Emblem & 4 Pillars (Art, Action, AI, Ambition) */}
        <CorporatePhilosophy />

        {/* Business Divisions Section - 아트판타지아가 걸어가는 길. */}
        <div className="mt-10 pt-8 border-t border-zinc-800/80">
          {/* Top Editorial Label - Art Fantasia Divisions */}
          <SectionEditorialHeader
            title="아트판타지아가 걸어가는 길."
            subtitle="사업영역 // BUSINESS DIVISIONS"
          />

          {/* Sophisticated Text-Centric Core Philosophy Quote */}
          <div className="my-10 sm:my-14 max-w-4xl mx-auto text-center px-4 select-none">
            <p className="font-['Noto_Sans_KR',sans-serif] text-xl sm:text-2xl md:text-3xl lg:text-[34px] font-black text-white tracking-tight leading-snug sm:leading-tight drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
              “우리에게 최고의 브랜드는 바로 <span className="text-amber-300 font-black">여러분의 이야기</span>”
            </p>
            <p className="text-xs sm:text-sm md:text-base text-zinc-400 leading-normal mt-2.5 max-w-2xl mx-auto font-normal font-['Noto_Sans_KR',sans-serif]">
              진정성 있는 스토리텔링과 타협 없는 오디오·비주얼 크래프트맨십으로
              <br />
              <span className="block mt-1 sm:mt-1 text-white font-bold drop-shadow-sm">
                여러분의 이야기를 <span className="text-amber-300 font-bold">A클래스 시네마틱</span> 경험으로 완성하겠습니다.
              </span>
            </p>
          </div>

          {/* 2 Divisions: 영상영역 & 음악영역 (가로형 와이드 레이아웃) */}
          <div className="space-y-6 sm:space-y-7">
            {/* 1. 영상영역 (FILM & VIDEO PRODUCTION) */}
            <div className="p-6 sm:p-8 lg:p-10 rounded-2xl bg-zinc-950/70 border border-zinc-800/90 hover:border-zinc-700/80 transition-all duration-300 shadow-xl group">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center">
                {/* Left Header Column */}
                <div className="relative lg:col-span-5 p-5 sm:p-6 rounded-xl bg-zinc-950 overflow-hidden shadow-xl group/box">
                  {/* DIREC.jpg Background Image */}
                  <div className="absolute inset-0 pointer-events-none">
                    <img
                      src="/DIREC.jpg"
                      alt="Film Direction"
                      className="w-full h-full object-cover object-center opacity-80 group-hover/box:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/30" />
                  </div>

                  <div className="relative z-10 space-y-3">
                    <div className="flex items-center gap-3">
                      <span className="text-4xl sm:text-5xl font-black font-mono text-zinc-300 group-hover:text-amber-300 transition-colors drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                        01
                      </span>
                      <div className="h-6 w-px bg-zinc-600/80" />
                      <span className="text-[11px] sm:text-xs font-mono tracking-widest text-amber-300 uppercase font-bold drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                        FILM & VIDEO PRODUCTION
                      </span>
                    </div>
                    <h3 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight font-['Noto_Sans_KR',sans-serif] drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]">
                      영상영역
                    </h3>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-950/90 border border-zinc-700/90 text-[11px] font-mono text-amber-300 font-semibold backdrop-blur-md shadow-lg">
                      <span>IN-HOUSE RESPONSIBILITY</span>
                    </div>
                  </div>
                </div>

                {/* Right Description & Action Button Column */}
                <div className="lg:col-span-7 space-y-4 lg:pl-6">
                  <div className="space-y-1.5">
                    <h4 className="text-sm sm:text-base font-bold text-white tracking-tight font-['Noto_Sans_KR',sans-serif] flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      기획에서부터 후반 작업까지 100% 책임제작
                    </h4>
                    <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed pl-3.5 font-normal font-['Noto_Sans_KR',sans-serif]">
                      아이디어 기획과 시나리오, 콘티, 연출, 4K/8K 시네마토그래피 촬영부터 편집 전반(CG, 색보정, 사운드 믹싱)까지... 대부분의 공정을 직영 인하우스 파이프라인을 통해 외주 최소화를 실현합니다.
                    </p>
                  </div>

                  <div className="pt-1 flex items-center justify-between flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => (onNavigate ? onNavigate('video') : onExploreVideo())}
                      className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white hover:bg-amber-400 text-black font-extrabold text-xs sm:text-sm transition-all duration-200 cursor-pointer shadow-sm hover:shadow-amber-400/20 group/btn"
                    >
                      <Film className="w-4 h-4 text-black shrink-0" />
                      <span>포트폴리오 바로가기</span>
                      <ArrowRight className="w-4 h-4 text-black shrink-0 transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              </div>

              {/* 하단으로 이동한 주요 제작 영역 5개 박스 (화면에 꽉 찬 5열 그리드) */}
              <div className="mt-8 pt-6 border-t border-zinc-800/80">
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5 sm:gap-3 w-full">
                  {[
                    {
                      num: '01',
                      title: 'AI 영상 제작',
                      sub: 'AI FILM & GEN-AI',
                      desc: '생성형 AI 워크플로우 & 가상 연출',
                      icon: Sparkles,
                    },
                    {
                      num: '02',
                      title: '홍보영상',
                      sub: 'CORPORATE & PR',
                      desc: '기업 · 정부 · 공공기관 공식 홍보',
                      icon: Building2,
                    },
                    {
                      num: '03',
                      title: '브랜드필름',
                      sub: 'BRAND CINEMA',
                      desc: '시네마틱 감성 스토리텔링',
                      icon: Film,
                    },
                    {
                      num: '04',
                      title: 'TVC 광고',
                      sub: 'TV COMMERCIAL',
                      desc: '지상파 & 케이블 온에어 심의 제작',
                      icon: Tv,
                    },
                    {
                      num: '05',
                      title: '유튜브 콘텐츠',
                      sub: 'YOUTUBE & WEB',
                      desc: '디지털 오리지널 & 브랜디드 영상',
                      icon: Play,
                    },
                  ].map((box, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 sm:p-4 rounded-xl bg-zinc-900/70 hover:bg-zinc-900 border border-zinc-800/80 hover:border-amber-400/50 transition-all duration-200 flex flex-col justify-between group/box min-h-[116px]"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-zinc-500 group-hover/box:text-amber-400 transition-colors">
                          {box.num}
                        </span>
                        <box.icon className="w-4 h-4 text-zinc-400 group-hover/box:text-amber-300 transition-colors" />
                      </div>
                      <div className="mt-3">
                        <div className="text-[18px] sm:text-[21px] font-bold text-amber-200 tracking-tight font-['Noto_Sans_KR',sans-serif] group-hover/box:text-amber-100 transition-colors">
                          {box.title}
                        </div>
                        <div className="text-[11px] text-zinc-400 mt-1 font-normal leading-tight font-['Noto_Sans_KR',sans-serif]">
                          {box.desc}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* 2. 음악영역 (MUSIC & AUDIO PRODUCTION) */}
            <div className="p-6 sm:p-8 lg:p-10 rounded-2xl bg-zinc-950/70 border border-zinc-800/90 hover:border-zinc-700/80 transition-all duration-300 shadow-xl group">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-center">
                {/* Left Header Column */}
                <div className="relative lg:col-span-5 p-5 sm:p-6 rounded-xl bg-zinc-950 overflow-hidden shadow-xl group/box">
                  {/* REC.jpg Background Image */}
                  <div className="absolute inset-0 pointer-events-none">
                    <img
                      src="/REC.jpg"
                      alt="Sound Recording"
                      className="w-full h-full object-cover object-center opacity-80 -scale-x-100 group-hover/box:-scale-x-105 group-hover/box:scale-y-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/55 to-black/30" />
                  </div>

                  <div className="relative z-10 space-y-3">
                    <div className="flex items-center gap-3">
                      <span className="text-4xl sm:text-5xl font-black font-mono text-zinc-300 group-hover:text-amber-300 transition-colors drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                        02
                      </span>
                      <div className="h-6 w-px bg-zinc-600/80" />
                      <span className="text-[11px] sm:text-xs font-mono tracking-widest text-amber-300 uppercase font-bold drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                        MUSIC & AUDIO PRODUCTION
                      </span>
                    </div>
                    <h3 className="text-2xl sm:text-3xl md:text-4xl font-black text-white tracking-tight font-['Noto_Sans_KR',sans-serif] drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)]">
                      음악영역
                    </h3>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-950/90 border border-zinc-700/90 text-[11px] font-mono text-amber-300 font-semibold backdrop-blur-md shadow-lg">
                      <span>DOLBY ATMOS® CERTIFIED SUITE</span>
                    </div>
                  </div>
                </div>

                {/* Right Description & Action Buttons Column */}
                <div className="lg:col-span-7 space-y-4 lg:pl-6">
                  <div className="space-y-1.5">
                    <h4 className="text-sm sm:text-base font-bold text-white tracking-tight font-['Noto_Sans_KR',sans-serif] flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                      기획에서부터 후반작업까지 100% 책임제작
                    </h4>
                    <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed pl-3.5 font-normal font-['Noto_Sans_KR',sans-serif]">
                      사운드 콘셉트 기획부터 작사·작곡, 편곡, 전문 성우·보컬 디렉팅 및 레코딩, 오디오 믹싱, 음향 마스터링까지 100% 직영 책임제작을 실현합니다.
                    </p>
                  </div>

                  <div className="pt-1 flex flex-wrap gap-3">
                    <button
                      type="button"
                      onClick={() => (onNavigate ? onNavigate('audio') : (onExploreAudio ? onExploreAudio() : undefined))}
                      className="inline-flex items-center gap-2 px-4.5 sm:px-5 py-2.5 rounded-xl bg-white hover:bg-amber-400 text-black font-extrabold text-xs sm:text-sm transition-all duration-200 cursor-pointer shadow-sm hover:shadow-amber-400/20 group/btn"
                    >
                      <Radio className="w-4 h-4 text-black shrink-0" />
                      <span>라디오광고 포트폴리오 바로가기</span>
                      <ArrowRight className="w-4 h-4 text-black shrink-0 transition-transform group-hover/btn:translate-x-1" />
                    </button>

                    <button
                      type="button"
                      onClick={() => (onNavigate ? onNavigate('afanmusic') : (onExploreAudio ? onExploreAudio() : undefined))}
                      className="inline-flex items-center gap-2 px-4.5 sm:px-5 py-2.5 rounded-xl bg-white hover:bg-amber-400 text-black font-extrabold text-xs sm:text-sm transition-all duration-200 cursor-pointer shadow-sm hover:shadow-amber-400/20 group/btn"
                    >
                      <Sparkles className="w-4 h-4 text-black shrink-0" />
                      <span>아판뮤직 바로가기</span>
                      <ArrowRight className="w-4 h-4 text-black shrink-0 transition-transform group-hover/btn:translate-x-1" />
                    </button>
                  </div>
                </div>
              </div>

              {/* 하단으로 이동한 음악 주요 제작 영역 4개 박스 (화면에 꽉 찬 4열 그리드) */}
              <div className="mt-8 pt-6 border-t border-zinc-800/80">
                <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3 w-full">
                  {[
                    {
                      num: '01',
                      title: '라디오광고',
                      sub: 'RADIO COMMERCIAL',
                      desc: '지상파 온에어 CM송 & 내레이션',
                      icon: Radio,
                    },
                    {
                      num: '02',
                      title: '오리지널 BGM',
                      sub: 'ORIGINAL SCORE',
                      desc: '방송 · 영상 전용 맞춤 배경음악',
                      icon: Music2,
                    },
                    {
                      num: '03',
                      title: '대중음악 & OST',
                      sub: 'POP ALBUM & OST',
                      desc: '음반 기획 · 작곡 · 편곡 · 레코딩',
                      icon: Headphones,
                    },
                    {
                      num: '04',
                      title: '브랜드 사운드',
                      sub: 'SIGNATURE JINGLE',
                      desc: '시그니처 징글 & 기업 로고송',
                      icon: Sparkles,
                    },
                  ].map((box, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 sm:p-4 rounded-xl bg-zinc-900/70 hover:bg-zinc-900 border border-zinc-800/80 hover:border-amber-400/50 transition-all duration-200 flex flex-col justify-between group/box min-h-[116px]"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono font-bold text-zinc-500 group-hover/box:text-amber-400 transition-colors">
                          {box.num}
                        </span>
                        <box.icon className="w-4 h-4 text-zinc-400 group-hover/box:text-amber-300 transition-colors" />
                      </div>
                      <div className="mt-3">
                        <div className="text-[18px] sm:text-[21px] font-bold text-amber-200 tracking-tight font-['Noto_Sans_KR',sans-serif] group-hover/box:text-amber-100 transition-colors">
                          {box.title}
                        </div>
                        <div className="text-[11px] text-zinc-400 mt-1 font-normal leading-tight font-['Noto_Sans_KR',sans-serif]">
                          {box.desc}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* Official Clients & Partners Showcase - 2-Row Infinite Left-to-Right Moving Ticker with sleek minimal boxes */}
        <div className="mt-16 pt-12 border-t border-zinc-800/80 max-w-[1340px] mx-auto">
          {/* Top Editorial Label - Art Fantasia Portfolio / 걸어온 길 */}
          <SectionEditorialHeader
            title={
              isTranslatedToEn ? (
                <span className="notranslate" translate="no">PORTFOLIO</span>
              ) : (
                <>
                  <span className="portfolio-lang-ko">아트판타지아가 걸어온 길.</span>
                  <span className="portfolio-lang-en hidden notranslate" translate="no">PORTFOLIO</span>
                </>
              )
            }
            subtitle="OFFICIAL CLIENTS & PARTNERS"
          />

          <div className="relative overflow-hidden w-full space-y-2 sm:space-y-2.5">
            {/* Left and Right Edge Gradient Masks for Seamless Aesthetic Fade */}
            <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-28 bg-gradient-to-r from-[#09090b] via-[#09090b]/80 to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-28 bg-gradient-to-l from-[#09090b] via-[#09090b]/80 to-transparent z-10 pointer-events-none" />

            {/* Row 1: Left to Right Continuous Moving Track */}
            <div className="overflow-hidden w-full">
              <div className="animate-marquee-ltr flex gap-2 sm:gap-2.5">
                {Array.from({ length: 16 }).map((_, idx) => renderMarqueeBox(`r1-a-${idx}`))}
                {Array.from({ length: 16 }).map((_, idx) => renderMarqueeBox(`r1-b-${idx}`))}
              </div>
            </div>

            {/* Row 2: Left to Right Continuous Moving Track */}
            <div className="overflow-hidden w-full">
              <div className="animate-marquee-ltr-offset flex gap-2 sm:gap-2.5">
                {Array.from({ length: 16 }).map((_, idx) => renderMarqueeBox(`r2-a-${idx}`))}
                {Array.from({ length: 16 }).map((_, idx) => renderMarqueeBox(`r2-b-${idx}`))}
              </div>
            </div>
          </div>
        </div>

        {/* International Global Portfolio from Company Profile Page 4 */}
        <InternationalPortfolio />

      </div>
    </section>
  );
};
