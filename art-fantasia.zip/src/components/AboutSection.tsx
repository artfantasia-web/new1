import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, Minimize, Quote } from 'lucide-react';

interface AboutSectionProps {
  onOpenInquiry?: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ onOpenInquiry: _onOpenInquiry }) => {
  const [activeTab, setActiveTab] = useState<'pipeline' | 'history'>('pipeline');

  // Video Showcase Player State
  const videoRef = useRef<HTMLVideoElement>(null);
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(40);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(true);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = false;
    }
    const handleFsChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement && document.fullscreenElement === videoContainerRef.current));
      setIsFullscreen2(Boolean(document.fullscreenElement && document.fullscreenElement === videoContainerRef2.current));
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  const handlePlayToggle = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
    } else {
      videoRef.current.muted = isMuted;
      videoRef.current.play().catch(() => {});
    }
  };

  const handleScrub = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const video = videoRef.current;
    if (!video) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const dur = video.duration && !isNaN(video.duration) && video.duration > 0 ? video.duration : (duration || 40);
    const targetTime = ratio * dur;
    video.currentTime = targetTime;
    setCurrentTime(targetTime);
  };

  const handleMuteToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleFullscreenToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoContainerRef.current) return;
    if (!document.fullscreenElement) {
      videoContainerRef.current.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleMouseMove = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;

  // Second Video Showcase Player State ("당신은 주인공 최고의 브랜드 입니다")
  const videoRef2 = useRef<HTMLVideoElement>(null);
  const videoContainerRef2 = useRef<HTMLDivElement>(null);
  const [isPlaying2, setIsPlaying2] = useState<boolean>(false);
  const [currentTime2, setCurrentTime2] = useState<number>(0);
  const [duration2, setDuration2] = useState<number>(154);
  const [isMuted2, setIsMuted2] = useState<boolean>(false);
  const [isFullscreen2, setIsFullscreen2] = useState<boolean>(false);
  const [showControls2, setShowControls2] = useState<boolean>(true);
  const controlsTimeoutRef2 = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (videoRef2.current) {
      videoRef2.current.muted = false;
    }
  }, []);

  const handlePlayToggle2 = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!videoRef2.current) return;
    if (isPlaying2) {
      videoRef2.current.pause();
    } else {
      videoRef2.current.muted = isMuted2;
      videoRef2.current.play().catch(() => {});
    }
  };

  const handleMuteToggle2 = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (videoRef2.current) {
      videoRef2.current.muted = !isMuted2;
      setIsMuted2(!isMuted2);
    }
  };

  const handleScrub2 = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const video = videoRef2.current;
    if (!video) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const dur = video.duration && !isNaN(video.duration) && video.duration > 0 ? video.duration : (duration2 || 154);
    const targetTime = ratio * dur;
    video.currentTime = targetTime;
    setCurrentTime2(targetTime);
  };

  const handleFullscreenToggle2 = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!videoContainerRef2.current) return;
    if (!document.fullscreenElement) {
      videoContainerRef2.current.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  };

  const handleMouseMove2 = () => {
    setShowControls2(true);
    if (controlsTimeoutRef2.current) {
      clearTimeout(controlsTimeoutRef2.current);
    }
    if (isPlaying2) {
      controlsTimeoutRef2.current = setTimeout(() => {
        setShowControls2(false);
      }, 3000);
    }
  };

  const progress2 = duration2 > 0 ? (currentTime2 / duration2) * 100 : 0;

  const historyMilestones = [
    { year: '2025', title: 'AI 혁신 시스템 고도화 & 프로덕션 체질 개선', desc: '미디어 패러다임의 변화에 선제적으로 대응하기 위해 AI 엔진 기반의 제작 시스템을 구축, 기획부터 연출·후반작업 전반에 걸친 스마트 프로덕션 체질 개선' },
    { year: '2024', title: '글로벌 프로덕션 브랜드 체계 개편', desc: '글로벌 프로덕션 스튜디오 도약을 위한 브랜드 시스템 고도화' },
    { year: '2019', title: 'SBS미디어크리에이트 방송광고거래 계약 & 영화상영등급필증', desc: '지상파 SBS 방송광고 공식 거래 계약 체결 및 영상물등급위원회 전체관람가 영화상영등급필증 획득' },
    { year: '2018', title: '한국무역협회 공식 회원 등록', desc: '글로벌 프로젝트 및 해외 현지 프로덕션 수출 역량 인증' },
    { year: '2017', title: '인도네시아 대통령 VIP VIEW & 글로벌 로케이션 촬영', desc: '인도네시아 대통령 VIP VIEW 프로젝트, 경기도경제과학진흥원 지원사업, 미국·일본·체코·중국·싱가포르 등 현지 촬영' },
    { year: '2016', title: 'KOBACO 방송광고거래 계약 & 콘텐츠제작센터 완공', desc: '한국방송광고진흥공사 방송광고거래 계약 체결, 대구 북구 학정로 아트판타지아 센터 완공 (자체 편집실, 녹음실, 설비실)' },
    { year: '2015', title: '아트판타지아 법인 설립 (12월)', desc: '세상을 영상과 음악으로 표현하는 하이엔드 크리에이티브 스튜디오 출범' }
  ];

  const pipelineSteps = [
    {
      num: '01',
      title: '크리에이티브 기획 & 전략 컨설팅',
      desc: '단순한 영상 제작을 넘어 브랜드 목표에 부합하는 콘셉트 도출과 시나리오·콘티 기획은 물론, 원활한 송출을 위한 방송광고 심의까지 사전에 완벽히 준비합니다.'
    },
    {
      num: '02',
      title: '시네마토그래피 & 현장 촬영',
      desc: 'ARRI, RED 시네마 카메라와 전문 조명, 특수 그립 장비를 갖추고 베테랑 연출진이 가장 선명한 비주얼을 포착합니다.'
    },
    {
      num: '03',
      title: '사운드 디자인 & 오디오 마스터링',
      desc: '자체 사운드 랩에서 전문 성우 녹음, 오리지널 BGM 작곡, 방송 및 라디오 CM 심의 규격 믹싱과 고품질 입체 음향 마스터링을 완성합니다.'
    },
    {
      num: '04',
      title: 'AI혁신',
      desc: '편집(CG, 정밀 색보정, 음향 마스터링) 후반작업 전반과 최신 AI 기술을 유기적으로 융합하여, 감각적이고 다채로운 고품질 영상을 완성하는 혁신적 제작 파이프라인입니다.'
    }
  ];

  return (
    <section id="about" className="py-16 sm:py-24 border-b border-zinc-800 bg-[#09090b] relative font-apple text-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Editorial Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-zinc-800 animate-header-reveal">
          <div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight font-apple">
              회사소개
            </h2>
            <p className="mt-3 text-base sm:text-lg font-medium text-zinc-300 flex items-center gap-2 flex-wrap">
              <span className="text-amber-400 font-bold shrink-0 text-base sm:text-lg">◉</span>
              <span className="text-amber-400 font-semibold text-base sm:text-lg">
                여러분의 이야기를 세상에 울려 퍼지게 하는 크리에이티브 파트너입니다.
              </span>
            </p>
          </div>
        </div>

        {/* Cinema Video Showcase: "대한민국에서 세상을 영상과 음악으로 표현합니다" */}
        <div className="w-full max-w-5xl mx-auto my-12 relative group">
          {/* Subtle Ambient Backlight Glow */}
          <div className="absolute -inset-2 rounded-2xl bg-white/[0.03] blur-2xl pointer-events-none" />

          {/* Interactive Cinema Video Container - Matching Hero Showreel */}
          <div
            ref={videoContainerRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={() => isPlaying && setShowControls(false)}
            className="relative rounded-lg border border-zinc-700/80 bg-zinc-950 overflow-hidden shadow-2xl select-none"
          >
            {/* Top Panel Bar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900/90 border-b border-zinc-800 text-xs font-mono text-zinc-400">
              <div className="flex items-center gap-3">
                <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
                <span className="text-zinc-200 font-medium">ART FANTASIA BRAND FILM // 00:40</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="hidden sm:inline">CODEC: H.264 / PRORES</span>
                <span className="text-amber-400 tabular-nums">
                  00:{formatTime(currentTime)} <span className="text-zinc-500">/ 00:00:40:00</span>
                </span>
              </div>
            </div>

            {/* Video Player Screen */}
            <div className="relative aspect-video w-full overflow-hidden bg-black flex items-center justify-center group">
              <video
                ref={videoRef}
                src="https://res.cloudinary.com/iwcoiohr/video/upload/v1792470332/%EB%8C%80%ED%95%9C%EB%AF%BC%EA%B5%AD%EC%97%90%EC%84%9C_%EC%84%B8%EC%83%81%EC%9D%84_%EC%98%81%EC%83%81%EA%B3%BC_%EC%9D%8C%EC%95%85%EC%9C%BC%EB%A1%9C_%ED%91%9C%ED%98%84%ED%95%A9%EB%8B%88%EB%8B%A4.mp4"
                poster="/assets/aistudio/1_20e10c79.jpg"
                playsInline
                muted={isMuted}
                preload="metadata"
                onClick={handlePlayToggle}
                className="w-full h-full object-cover block cursor-pointer"
                onPlay={() => {
                  setIsPlaying(true);
                  setShowControls(true);
                }}
                onPause={() => {
                  setIsPlaying(false);
                  setShowControls(true);
                }}
                onTimeUpdate={() => {
                  setCurrentTime(videoRef.current?.currentTime || 0);
                }}
                onLoadedMetadata={() => {
                  setDuration(videoRef.current?.duration || 40);
                }}
                onEnded={() => {
                  setIsPlaying(false);
                  setShowControls(true);
                }}
              />

              {/* Custom Poster Thumbnail (Image 1) */}
              {!isPlaying && currentTime === 0 && (
                <img
                  src="/assets/aistudio/1_20e10c79.jpg"
                  alt="세상을 영상과 음악으로 표현합니다 썸네일"
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none z-10"
                />
              )}

              {/* Cinematic Center Overlay & Play Button (Matching Showreel Standard) */}
              {!isPlaying && (
                <div
                  onClick={handlePlayToggle}
                  className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center cursor-pointer z-15 bg-black/15 hover:bg-black/25 transition-colors group/overlay"
                >
                  <span className="text-xs sm:text-sm font-mono tracking-wider font-bold text-amber-400 uppercase mb-2 drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                    Brand Film · Philosophy · Vision
                  </span>
                  <h3 className="text-lg sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-white tracking-tight drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)] mb-6 font-apple">
                    세상을 영상과 음악으로 표현합니다.
                  </h3>

                  {/* Standard 111 Gradient Play Button */}
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-r from-[#F15A29] via-[#E9422F] to-[#DD2426] text-white flex items-center justify-center shadow-[0_0_35px_rgba(233,66,47,0.6)] group-hover/overlay:scale-110 group-hover/overlay:shadow-[0_0_50px_rgba(233,66,47,0.85)] transition-all duration-300">
                    <Play className="w-7 h-7 sm:w-9 sm:h-9 fill-white ml-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.3)]" />
                  </div>

                  {/* Standard Play Description */}
                  <span className="text-xs sm:text-sm text-zinc-200 mt-4 font-medium drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                    재생 버튼 또는 화면을 클릭하시면 영상을 감상하실 수 있습니다
                  </span>
                </div>
              )}

              {/* Player Controls Overlay - Matching Showreel */}
              <div
                onClick={(e) => e.stopPropagation()}
                className={`absolute bottom-2 sm:bottom-3 left-2 sm:left-4 right-2 sm:right-4 flex items-center justify-between gap-4 py-2 px-3.5 bg-black/80 backdrop-blur-md rounded border border-white/10 z-20 transition-opacity duration-300 ${
                  showControls || !isPlaying ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
                }`}
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={handlePlayToggle}
                    className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 cursor-pointer"
                    aria-label={isPlaying ? '일시 정지' : '재생'}
                  >
                    {isPlaying ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                  </button>
                  <button
                    onClick={handleMuteToggle}
                    className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                    aria-label={isMuted ? '음소거 해제' : '음소거'}
                  >
                    {isMuted ? <VolumeX className="w-4 h-4 text-zinc-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                    <span className="text-[11px] font-mono text-zinc-300 hidden sm:inline">
                      {isMuted ? 'MUTE' : 'AUDIO ON'}
                    </span>
                  </button>
                </div>

                {/* Progress Bar & Time Scrubber */}
                <div className="flex-1 mx-2 flex items-center gap-3">
                  <div
                    className="flex-1 h-1.5 bg-zinc-700/80 rounded overflow-hidden cursor-pointer relative"
                    onClick={handleScrub}
                  >
                    <div
                      className="h-full bg-amber-400 transition-all duration-75"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                  <span className="text-xs font-mono text-zinc-300 tabular-nums">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>

                <button
                  onClick={handleFullscreenToggle}
                  className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 cursor-pointer"
                  aria-label={isFullscreen ? '전체화면 종료' : '전체화면'}
                >
                  {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* CEO Message: 사랑하는 세상으로의 나아감에 "예술"이라는 답을 제시합니다 */}
        <div className="w-full max-w-5xl mx-auto my-10 relative group font-apple">
          {/* Subtle Ambient Backlight Glow */}
          <div className="absolute -inset-2 rounded-3xl bg-amber-500/[0.04] blur-2xl pointer-events-none" />

          {/* Elegant Editorial Letter Container with Subtle Building Background Artwork */}
          <div className="relative rounded-2xl bg-gradient-to-b from-zinc-950/95 via-zinc-900/80 to-zinc-950 py-7 sm:py-11 md:py-14 px-6 sm:px-10 md:px-12 border border-zinc-800 shadow-[0_20px_50px_rgba(0,0,0,0.8)] overflow-hidden">
            {/* Ambient Background Artwork (Uploaded Transparent Building Cutout PNG) - 300% Enlarged, Softer & Slow Pan Animation */}
            <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden rounded-2xl flex items-center justify-center">
              <div className="w-full h-full flex items-center justify-center animate-slow-pan">
                <img
                  src="/assets/aistudio/build1_023228e9.png"
                  alt="ArtFantasia Building Artwork"
                  className="w-full h-full min-w-[1020px] sm:min-w-[1320px] md:min-w-[1450px] max-w-none object-cover sm:object-contain object-center opacity-25 sm:opacity-30 filter contrast-110 brightness-105 select-none"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src = '/B2.png';
                  }}
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-b from-zinc-950/75 via-zinc-950/45 to-zinc-950/80 pointer-events-none" />
            </div>

            {/* Background Decorative Large Quote Watermark */}
            <Quote className="w-24 h-24 text-amber-400/[0.04] absolute -top-3 -left-3 pointer-events-none z-0" />
            <div className="absolute -bottom-20 -right-20 w-72 h-72 bg-amber-400/[0.03] rounded-full blur-3xl pointer-events-none z-0" />

            {/* Header: CEO Message Tag & Headline (Expanded 5% Spacing) */}
            <div className="relative z-10 mb-7 pb-4.5 border-b border-zinc-800/80 text-center">
              <div className="inline-flex items-center gap-2 px-3 py-0.5 rounded-full bg-amber-400/10 border border-amber-400/25 text-xs font-mono text-amber-400 font-semibold tracking-wider mb-2.5 mx-auto">
                <Quote className="w-3.5 h-3.5 text-amber-400" />
                <span>CEO MESSAGE // 대표 인사말</span>
              </div>
              <h3 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-white tracking-tight leading-snug text-center">
                여러분이 사랑하는 세상으로의 나아감에 <br className="hidden sm:inline" />
                <span className="bg-gradient-to-r from-amber-200 via-amber-400 to-amber-500 bg-clip-text text-transparent">
                  "예술"
                </span>
                이라는 답을 선물하고자 합니다.
              </h3>
            </div>

            {/* Body Letter Text (Vertical Spacing 5% Expanded: space-y-[17px] & leading-[1.8]) */}
            <div className="relative z-10 space-y-[17px] text-center max-w-2xl mx-auto text-sm sm:text-[15px] md:text-base text-zinc-200 leading-[1.8] font-normal tracking-wide drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
              <p>
                세상은 빠르게 변화하고 있고<br />
                세상은 새로운 것을 요구할 때가 많습니다.
              </p>

              <p>
                이것은<br />
                세상에 자신의 꿈을 그리고 신념을 펼치기 위해<br />
                하루하루 바쁜 나날을 보내시는<br />
                클라이언트 분들에게는<br />
                큰 고민 중 하나일 것입니다.
              </p>

              <p>
                세상은 빠르게 변화하고 새로운 것을 요구하지만<br />
                변하지 않는 단 하나의 진리가 있습니다.
              </p>

              <p>
                인류가 생긴 이래 지금까지 이어져온<br />
                <span className="text-amber-400 font-bold">"예술"</span>이라는 행위는<br />
                변하지 않았고 앞으로도 변하지 않기 때문입니다.
              </p>

              <p>
                세상의 모든 여성이 자신을 표현하기 위해<br />
                스스로를 가꾸 듯<br />
                <span className="text-amber-400 font-bold">"예술"</span>로<br />
                여러분의 꿈과 신념을 가꾸어 보셨으면 합니다.
              </p>

              <p>
                세상의 변화와 새로움의 요구를<br />
                분명 현명하게 대처하실 수 있을 것 입니다.
              </p>

              <p className="text-sm sm:text-base text-white font-medium pt-1">
                여러분이 사랑하는 세상으로의 나아감에<br />
                <span className="text-amber-400 font-bold">"예술"</span>이라는<br />
                답을 선물하고자 합니다.
              </p>
            </div>

            {/* Closing Brand Text (Expanded 5% Spacing) */}
            <div className="relative z-10 mt-7 pt-5.5 border-t border-zinc-800/80 text-center max-w-2xl mx-auto space-y-2">
              <p className="text-sm sm:text-base text-zinc-300 font-medium leading-relaxed">
                아트판타지아(ArtFantasia)는<br />
                영상과 음악을 제작하는
              </p>
              <p className="text-base sm:text-xl font-black text-amber-400 tracking-tight">
                "대한민국 문화컨텐츠 여성기업 브랜드"입니다.
              </p>
            </div>

            {/* Bottom Signature Line (Expanded 5% Spacing) */}
            <div className="relative z-10 mt-7 pt-4.5 border-t border-zinc-800/80 text-center">
              <p className="text-xs sm:text-sm text-zinc-400 font-medium">
                주식회사 아트판타지아 대표이사 및 크리에이티브 디렉터 드림
              </p>
            </div>
          </div>
        </div>

        {/* Tabbed In-Depth Architecture: Pipeline & History */}
        <div className="mt-12 sm:mt-16 bg-zinc-950 rounded-lg border border-zinc-800/80 overflow-hidden">
          {/* Tab Header Controls */}
          <div className="flex border-b border-zinc-800 bg-zinc-900/60 p-2 gap-2 overflow-x-auto">
            <button
              onClick={() => setActiveTab('pipeline')}
              className={`px-5 py-2.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'pipeline'
                  ? 'bg-zinc-800 text-amber-400 font-bold shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              01. 올인원 제작 파이프라인
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-5 py-2.5 text-xs sm:text-sm font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-zinc-800 text-amber-400 font-bold shadow'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              02. 대표연혁
            </button>
          </div>

          {/* Tab 2: Pipeline */}
          {activeTab === 'pipeline' && (
            <div className="p-8 sm:p-10">
              <div className="max-w-5xl mb-8">
                <span className="text-xs font-mono text-amber-400">END-TO-END WORKFLOW</span>
                <h4 className="text-2xl font-bold text-white mt-1">
                  기획부터 심의·온에어·마케팅까지 단 하나의 창구
                </h4>
                <p className="mt-2 text-sm sm:text-base text-zinc-300 leading-relaxed lg:whitespace-nowrap">
                  외주 외주를 거듭하는 번거로움 없이, 전속 크리에이티브 팀이 기획부터 촬영, 편집, 온에어 및 사후관리(A/S)까지 완벽히 책임집니다.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {pipelineSteps.map((step, idx) => (
                  <div key={idx} className="p-5 rounded bg-zinc-900/60 border border-zinc-800 flex flex-col justify-between">
                    <div>
                      <span className="text-xl font-extrabold text-amber-400 font-mono">{step.num}</span>
                      <h5 className="text-[15px] sm:text-base font-bold text-amber-300 mt-2 mb-2 leading-snug">{step.title}</h5>
                      <p className="text-xs text-zinc-400 leading-relaxed">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 3: History */}
          {activeTab === 'history' && (
            <div className="p-8 sm:p-10">
              <div className="max-w-2xl mb-8">
                <span className="text-xs font-mono text-amber-400">OUR HERITAGE</span>
                <h4 className="text-2xl font-bold text-white mt-1">
                  꿈을 향해 끊임없이 달려온 시간들.
                </h4>
                <p className="mt-2 text-sm text-zinc-400">
                  수많은 브랜드와 공공기관의 파트너로서 그리고 대한민국 넘어 넓은 세상을 표현하기 위해 달려왔습니다.
                </p>
              </div>

              <div className="space-y-6">
                {historyMilestones.map((h, idx) => (
                  <div key={idx} className="flex flex-col sm:flex-row sm:items-start gap-4 pb-6 border-b border-zinc-800/70 last:border-0 last:pb-0">
                    <div className="text-2xl font-extrabold text-amber-400 font-mono w-24 shrink-0">
                      {h.year}
                    </div>
                    <div>
                      <h5 className="text-base font-bold text-white">{h.title}</h5>
                      <p className="text-sm text-zinc-400 mt-1 leading-relaxed">{h.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Cinema Video Showcase 2: "당신은 주인공 최고의 브랜드 입니다" (No Mute Feature as requested) */}
        <div className="w-full max-w-5xl mx-auto my-12 relative group font-apple">
          {/* Subtle Ambient Backlight Glow */}
          <div className="absolute -inset-2 rounded-2xl bg-white/[0.03] blur-2xl pointer-events-none" />

          {/* Interactive Cinema Video Container - Matching Hero Showreel */}
          <div
            ref={videoContainerRef2}
            onMouseMove={handleMouseMove2}
            onMouseLeave={() => isPlaying2 && setShowControls2(false)}
            className="relative rounded-lg border border-zinc-700/80 bg-zinc-950 overflow-hidden shadow-2xl select-none"
          >
            {/* Top Panel Bar */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-zinc-900/90 border-b border-zinc-800 text-xs font-mono text-zinc-400">
              <div className="flex items-center gap-3">
                <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
                <span className="text-zinc-200 font-medium">ART FANTASIA BRAND FILM // 02:34</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="hidden sm:inline">CODEC: H.264 / PRORES</span>
                <span className="text-amber-400 tabular-nums">
                  00:{formatTime(currentTime2)} <span className="text-zinc-500">/ 00:02:34:00</span>
                </span>
              </div>
            </div>

            {/* Video Player Screen */}
            <div className="relative aspect-video w-full overflow-hidden bg-black flex items-center justify-center group">
              <video
                ref={videoRef2}
                src="https://res.cloudinary.com/iwcoiohr/video/upload/v1792471213/%EB%8B%B9%EC%8B%A0%EC%9D%80_%EC%A3%BC%EC%9D%B8%EA%B3%B5_%EC%B5%9C%EA%B3%A0%EC%9D%98_%EB%B8%8C%EB%9E%9C%EB%93%9C_%EC%9E%85%EB%8B%88%EB%8B%A4.mp4"
                poster="/assets/aistudio/2_19c8f5de.jpg"
                playsInline
                muted={isMuted2}
                preload="metadata"
                onClick={handlePlayToggle2}
                className="w-full h-full object-cover block cursor-pointer"
                onPlay={() => {
                  setIsPlaying2(true);
                  setShowControls2(true);
                }}
                onPause={() => {
                  setIsPlaying2(false);
                  setShowControls2(true);
                }}
                onTimeUpdate={() => {
                  setCurrentTime2(videoRef2.current?.currentTime || 0);
                }}
                onLoadedMetadata={() => {
                  setDuration2(videoRef2.current?.duration || 154);
                }}
                onEnded={() => {
                  setIsPlaying2(false);
                  setShowControls2(true);
                }}
              />

              {/* Custom Poster Thumbnail (Image 2 - Moving Forward) */}
              {!isPlaying2 && currentTime2 === 0 && (
                <img
                  src="/assets/aistudio/2_19c8f5de.jpg"
                  alt="당신은 주인공 최고의 브랜드 입니다 썸네일 (Moving Forward)"
                  className="absolute inset-0 w-full h-full object-cover pointer-events-none z-10"
                />
              )}

              {/* Cinematic Center Overlay & Play Button (Matching Showreel Standard) */}
              {!isPlaying2 && (
                <div
                  onClick={handlePlayToggle2}
                  className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center cursor-pointer z-15 bg-black/15 hover:bg-black/25 transition-colors group/overlay"
                >
                  <span className="text-xs sm:text-sm font-mono tracking-wider font-bold text-amber-400 uppercase mb-2 drop-shadow-[0_2px_8px_rgba(0,0,0,0.95)]">
                    Brand Film · Special Campaign · Vision
                  </span>
                  <h3 className="text-lg sm:text-2xl md:text-3xl lg:text-4xl font-extrabold text-white tracking-tight drop-shadow-[0_4px_16px_rgba(0,0,0,0.95)] mb-6 font-apple">
                    당신은 주인공 최고의 브랜드 입니다
                  </h3>

                  {/* Standard 111 Gradient Play Button */}
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-r from-[#F15A29] via-[#E9422F] to-[#DD2426] text-white flex items-center justify-center shadow-[0_0_35px_rgba(233,66,47,0.6)] group-hover/overlay:scale-110 group-hover/overlay:shadow-[0_0_50px_rgba(233,66,47,0.85)] transition-all duration-300">
                    <Play className="w-7 h-7 sm:w-9 sm:h-9 fill-white ml-1 drop-shadow-[0_2px_6px_rgba(0,0,0,0.3)]" />
                  </div>

                  {/* Standard Play Description */}
                  <span className="text-xs sm:text-sm text-zinc-200 mt-4 font-medium drop-shadow-[0_2px_6px_rgba(0,0,0,0.95)]">
                    재생 버튼 또는 화면을 클릭하시면 영상을 감상하실 수 있습니다
                  </span>
                </div>
              )}

              {/* Player Controls Overlay - (No Mute Button, plays unmuted with sound as requested) */}
              <div
                onClick={(e) => e.stopPropagation()}
                className={`absolute bottom-2 sm:bottom-3 left-2 sm:left-4 right-2 sm:right-4 flex items-center justify-between gap-4 py-2 px-3.5 bg-black/80 backdrop-blur-md rounded border border-white/10 z-20 transition-opacity duration-300 ${
                  showControls2 || !isPlaying2 ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
                }`}
              >
                <div className="flex items-center gap-3">
                  <button
                    onClick={handlePlayToggle2}
                    className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 cursor-pointer"
                    aria-label={isPlaying2 ? '일시 정지' : '재생'}
                  >
                    {isPlaying2 ? <Pause className="w-4 h-4 fill-white" /> : <Play className="w-4 h-4 fill-white" />}
                  </button>
                  <button
                    onClick={handleMuteToggle2}
                    className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 flex items-center gap-1.5 cursor-pointer"
                    aria-label={isMuted2 ? '음소거 해제' : '음소거'}
                  >
                    {isMuted2 ? <VolumeX className="w-4 h-4 text-zinc-400" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                    <span className="text-[11px] font-mono text-zinc-300 hidden sm:inline">
                      {isMuted2 ? 'MUTE' : 'AUDIO ON'}
                    </span>
                  </button>
                </div>

                {/* Progress Bar & Time Scrubber */}
                <div className="flex-1 mx-2 flex items-center gap-3">
                  <div
                    className="flex-1 h-1.5 bg-zinc-700/80 rounded overflow-hidden cursor-pointer relative"
                    onClick={handleScrub2}
                  >
                    <div
                      className="h-full bg-amber-400 transition-all duration-75"
                      style={{ width: `${progress2}%` }}
                    />
                  </div>
                  <span className="text-xs font-mono text-zinc-300 tabular-nums">
                    {formatTime(currentTime2)} / {formatTime(duration2)}
                  </span>
                </div>

                <button
                  onClick={handleFullscreenToggle2}
                  className="p-1.5 text-white hover:text-amber-400 transition-colors rounded hover:bg-white/5 cursor-pointer"
                  aria-label={isFullscreen2 ? '전체화면 종료' : '전체화면'}
                >
                  {isFullscreen2 ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
