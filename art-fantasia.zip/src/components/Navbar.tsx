import React, { useState, useEffect } from 'react';
import { NavCategory } from '../types';
import { Menu, X, ArrowUpRight, Send } from 'lucide-react';

interface NavbarProps {
  activeSection: NavCategory;
  onNavigate: (section: NavCategory) => void;
  onOpenInquiry: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, onNavigate, onOpenInquiry }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { id: NavCategory; label: string; sub: string }[] = [
    { id: 'about', label: '회사소개', sub: 'ABOUT' },
    { id: 'video', label: '영상제작', sub: 'FILM' },
    { id: 'audio', label: '라디오광고', sub: 'RADIO' },
    { id: 'afanmusic', label: '아판뮤직', sub: 'AFAN MUSIC' },
    { id: 'marketing', label: '마케팅', sub: 'MARKETING' },
    { id: 'notice', label: '공지사항', sub: 'NOTICE' },
  ];

  const handleNavClick = (id: NavCategory) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <>
      <header
        className={`sticky top-0 z-50 w-full backdrop-blur-md border-b transition-all duration-300 ${
          isScrolled ? 'bg-[#09090b]/98 border-zinc-800 shadow-2xl py-3' : 'bg-[#09090b]/90 border-zinc-800/80 py-3.5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 sm:px-8">
          {/* Top Bar: Brand Logo on Left (Go to Home) & Category Links on Right */}
          <div className="flex items-center justify-between gap-8">
            {/* Zone 1: Official Brand Logo Image (Click to Navigate to Home) */}
            <button
              onClick={() => handleNavClick('home')}
              className="group flex items-center text-left whitespace-nowrap shrink-0 transition-opacity hover:opacity-80 cursor-pointer py-0.5"
              aria-label="아트판타지아 홈으로 이동"
              title="홈으로 이동"
            >
              <img
                src="/01lo.png"
                alt="Art Fantasia"
                className="h-7 sm:h-8 w-auto object-contain transition-transform duration-300 group-hover:scale-[1.02]"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    'https://github.com/artfantasia-web/new1/blob/main/01lo.png?raw=true';
                }}
              />
            </button>

            {/* Zone 2: Clean Single-Line Nav Links + 제작문의 Button */}
            <nav className="hidden lg:flex items-center gap-6 xl:gap-8 font-apple antialiased">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`group relative py-1.5 px-0.5 text-[15px] font-semibold tracking-tight transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer ${
                      isActive
                        ? 'text-amber-400 font-bold'
                        : 'text-zinc-300 hover:text-amber-300'
                    }`}
                  >
                    <span>{item.label}</span>
                    <span
                      className={`absolute bottom-0 left-0 h-[2px] rounded-full transition-all duration-200 ${
                        isActive
                          ? 'w-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                          : 'w-0 bg-amber-400/50 group-hover:w-full'
                      }`}
                    />
                  </button>
                );
              })}

              {/* 제작문의 버튼 */}
              <button
                onClick={() => handleNavClick('inquiry')}
                className={`ml-1 inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-[13px] font-bold font-apple tracking-tight transition-all duration-200 cursor-pointer shadow-md ${
                  activeSection === 'inquiry'
                    ? 'bg-amber-300 text-black ring-2 ring-amber-400 shadow-amber-400/20'
                    : 'bg-amber-400 hover:bg-amber-300 text-black hover:scale-[1.02]'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>제작문의</span>
              </button>
            </nav>

            {/* Mobile Menu Hamburger */}
            <div className="flex items-center lg:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 text-zinc-300 hover:text-white rounded focus:outline-none cursor-pointer"
                aria-label="메뉴 열기"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 lg:hidden bg-black/95 backdrop-blur-xl pt-24 px-6 flex flex-col justify-between pb-10">
          <div className="space-y-4">
            <div className="text-xs uppercase tracking-widest text-zinc-500 font-mono mb-6">
              Navigation Menu
            </div>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between py-3.5 border-b border-zinc-800 text-left text-lg font-semibold font-apple tracking-tight transition-colors ${
                  activeSection === item.id
                    ? 'text-amber-400 font-bold'
                    : 'text-zinc-100 hover:text-white'
                }`}
              >
                <span className="font-apple">{item.label}</span>
                <span className="text-xs font-mono text-zinc-500">{item.sub}</span>
              </button>
            ))}
          </div>

          <div className="pt-6 border-t border-zinc-800 space-y-4">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenInquiry();
              }}
              className="w-full py-3.5 text-center text-sm font-semibold text-black bg-amber-400 rounded hover:bg-amber-300 flex items-center justify-center gap-2"
            >
              <span>프로젝트 제작 및 견적 문의하기</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
            <div className="text-xs text-zinc-500 text-center font-mono">
              TEL: 010-8739-8611 · artfantasia01@gmail.com
            </div>
          </div>
        </div>
      )}
    </>
  );
};
