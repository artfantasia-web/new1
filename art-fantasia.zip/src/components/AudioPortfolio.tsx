import React, { useState, useEffect, useRef } from 'react';
import { AUDIO_TRACKS } from '../data/content';
import { AudioTrack, AudioCategory } from '../types';
import { 
  Play, 
  Pause, 
  Volume1, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  X, 
  Radio, 
  Sparkles, 
  FileText, 
  Share2, 
  Check, 
  ShieldCheck, 
  Mic, 
  ArrowRight, 
  Clock, 
  Award, 
  Headphones
} from 'lucide-react';

interface AudioPortfolioProps {
  onOpenInquiry?: () => void;
}

export const AudioPortfolio: React.FC<AudioPortfolioProps> = ({ onOpenInquiry: _onOpenInquiry }) => {
  const [selectedCategory, setSelectedCategory] = useState<AudioCategory>('all');
  
  // Dedicated Screening Window Modal State (Matching VideoPortfolio.tsx activeProject style)
  const [screeningTrack, setScreeningTrack] = useState<AudioTrack | null>(null);
  const [isModalPlaying, setIsModalPlaying] = useState<boolean>(true);
  const [modalTime, setModalTime] = useState<number>(0);
  const [modalDuration, setModalDuration] = useState<number>(20);
  const [modalVolume, setModalVolume] = useState<number>(0.85);
  const [isModalMuted, setIsModalMuted] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const modalAudioRef = useRef<HTMLAudioElement | null>(null);
  const modalCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const categories: { id: AudioCategory; label: string }[] = [
    { id: 'all', label: `전체 라디오광고 (${AUDIO_TRACKS.length})` },
    { id: 'radio_cm', label: '나레이션 & 스토리 CM' },
    { id: 'logo_song', label: '브랜드 CM송 & 징글' },
    { id: 'public_cm', label: '공익 & 지자체·KOBACO' },
    { id: 'lifestyle', label: '로컬 & 라이프스타일' }
  ];

  const filteredTracks = selectedCategory === 'all'
    ? AUDIO_TRACKS
    : AUDIO_TRACKS.filter(t => t.category === selectedCategory);



  // Open screening window modal with a selected audio track
  const handleOpenScreening = (track: AudioTrack) => {
    setScreeningTrack(track);
    setIsModalPlaying(true);
    setModalTime(0);
    setModalDuration(track.durationSeconds || 20);
  };

  // Close screening window modal and pause audio
  const handleCloseScreening = () => {
    if (modalAudioRef.current) {
      modalAudioRef.current.pause();
    }
    setIsModalPlaying(false);
    setScreeningTrack(null);
  };

  // Handle track switch inside modal or when modal opens
  useEffect(() => {
    if (screeningTrack) {
      setIsModalPlaying(true);
      setModalTime(0);
      setModalDuration(screeningTrack.durationSeconds || 20);

      // Attempt autoplay after audio element is mounted
      const timer = setTimeout(() => {
        if (modalAudioRef.current) {
          modalAudioRef.current.currentTime = 0;
          modalAudioRef.current.volume = isModalMuted ? 0 : modalVolume;
          modalAudioRef.current.play().catch(() => {
            setIsModalPlaying(false);
          });
        }
      }, 50);

      return () => clearTimeout(timer);
    } else {
      if (modalAudioRef.current) {
        modalAudioRef.current.pause();
      }
      setIsModalPlaying(false);
    }
  }, [screeningTrack]);

  // Audio Canvas visualizer loop for screening modal
  useEffect(() => {
    const canvas = modalCanvasRef.current;
    if (!canvas || !screeningTrack) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      phase += 0.08;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const bars = 56;
      const barWidth = canvas.width / bars - 2;

      for (let i = 0; i < bars; i++) {
        const x = i * (barWidth + 2);
        // Harmonic height formula based on playing state
        let heightMultiplier = isModalPlaying
          ? Math.sin(phase + i * 0.28) * 0.42 + Math.cos(phase * 1.6 + i * 0.12) * 0.32 + 0.52
          : 0.08;

        if (heightMultiplier < 0.05) heightMultiplier = 0.05;
        const barHeight = Math.min(canvas.height, heightMultiplier * (canvas.height - 8));
        const y = canvas.height - barHeight;

        // Rich vibrant gradient matching ArtFantasia orange-red broadcast aesthetic
        const grad = ctx.createLinearGradient(0, y, 0, canvas.height);
        grad.addColorStop(0, '#fbbf24'); // Amber 400
        grad.addColorStop(0.5, '#f59e0b'); // Amber 500
        grad.addColorStop(1, '#ef4444'); // Red 500

        ctx.fillStyle = isModalPlaying ? grad : '#3f3f46';
        // Rounded bar top
        ctx.beginPath();
        ctx.roundRect ? ctx.roundRect(x, y, barWidth, barHeight, [2, 2, 0, 0]) : ctx.rect(x, y, barWidth, barHeight);
        ctx.fill();
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isModalPlaying, screeningTrack]);

  // Toggle modal play/pause
  const toggleModalPlay = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!modalAudioRef.current) return;
    if (isModalPlaying) {
      modalAudioRef.current.pause();
      setIsModalPlaying(false);
    } else {
      modalAudioRef.current.play().catch(() => {});
      setIsModalPlaying(true);
    }
  };

  // Replay modal audio from 0
  const handleModalReplay = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!modalAudioRef.current) return;
    modalAudioRef.current.currentTime = 0;
    setModalTime(0);
    modalAudioRef.current.play().catch(() => {});
    setIsModalPlaying(true);
  };

  // Handle seek / scrub on progress bar
  const handleModalSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const targetDuration = modalDuration || screeningTrack?.durationSeconds || 20;
    const newTime = ratio * targetDuration;
    if (modalAudioRef.current) {
      modalAudioRef.current.currentTime = newTime;
      setModalTime(newTime);
    }
  };

  // Volume slider & mute
  const handleModalVolumeChange = (newVol: number) => {
    const clamped = Math.max(0, Math.min(1, newVol));
    setModalVolume(clamped);
    setIsModalMuted(clamped === 0);
    if (modalAudioRef.current) {
      modalAudioRef.current.volume = clamped;
      modalAudioRef.current.muted = clamped === 0;
    }
  };

  const handleVolumeBarClick = (e: React.MouseEvent<HTMLDivElement>) => {
    e.stopPropagation();
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    handleModalVolumeChange(Math.round(ratio * 100) / 100);
  };

  const toggleModalMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextMute = !isModalMuted;
    setIsModalMuted(nextMute);
    if (modalAudioRef.current) {
      modalAudioRef.current.muted = nextMute;
      if (!nextMute && modalVolume === 0) {
        modalAudioRef.current.volume = 0.85;
        setModalVolume(0.85);
      }
    }
  };

  const copyTrackLink = (track: AudioTrack, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(`${window.location.origin}#audio-${track.id}`);
    setCopiedId(track.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const formatAudioTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const modalProgressPercent = modalDuration > 0 ? (modalTime / modalDuration) * 100 : 0;

  return (
    <section id="audio" className="py-24 border-b border-zinc-800 bg-[#09090b] relative font-apple text-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Section Header */}
        <div className="pb-8 border-b border-zinc-800 animate-header-reveal">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold font-apple text-white tracking-tight">
            라디오광고제작 포트폴리오
          </h2>
          <p className="mt-3 text-sm sm:text-base font-medium text-zinc-300 flex items-center gap-2 flex-wrap font-apple">
            <span className="text-amber-400 font-bold shrink-0 text-sm sm:text-base">◉</span>
            <span className="text-amber-400 font-semibold text-sm sm:text-base">
              기획, 성우 섭외, 로고송 작곡, 음향 마스터링, 방송 심의 전 과정 <span className="font-black text-amber-300 underline decoration-amber-400/60 underline-offset-4">100% 진행</span>
            </span>
          </p>
        </div>

        {/* Radio Production Process & Clearance Strip (One-Stop Sequential Pipeline) */}
        <div className="mt-8 relative font-apple">
          {/* Pipeline Header Label */}
          <div className="flex items-center justify-between mb-3 px-1 text-[11px] font-mono text-zinc-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span className="text-zinc-300 font-semibold uppercase tracking-wider">ONE-STOP PRODUCTION PIPELINE</span>
              <span className="text-zinc-600">·</span>
              <span className="text-zinc-400">라디오 광고 원스톱 직결 제작 순서</span>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 text-amber-400/80 text-[11px]">
              <span>순차 진행 프로세스</span>
              <ArrowRight className="w-3 h-3 animate-flow-arrow" />
            </div>
          </div>

          {/* Process Flow Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative">
            {/* Step 1: 광고 소재 직접 기획 · 제작 */}
            <div className="relative rounded-xl bg-zinc-950/85 border border-zinc-800/80 hover:border-amber-400/50 p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(245,158,11,0.08)] flex flex-col justify-between group">
              <div>
                <div className="flex items-center justify-between pb-2.5 border-b border-zinc-800/70">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/30 text-amber-300 font-mono text-[11px] font-bold">
                      STEP 01
                    </span>
                    <span className="flex items-center gap-1 text-[11.5px] font-medium text-zinc-300">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      소재 기획·제작
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                    인하우스
                  </span>
                </div>

                <div className="h-24 rounded-lg overflow-hidden relative my-3 bg-zinc-900 border border-zinc-800/50">
                  <img
                    src="https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=800&auto=format&fit=crop"
                    alt="라디오 광고 소재 직접 기획 및 음원 제작"
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-transparent to-transparent" />
                </div>

                <h4 className="text-[15px] sm:text-[16px] font-bold text-white group-hover:text-amber-400 transition-colors mb-1.5 leading-snug">
                  광고 소재 직접 기획 · 제작
                </h4>
                <p className="text-[11.5px] sm:text-[12px] text-zinc-400 leading-relaxed">
                  카피라이팅부터 로고송·징글 작곡 및 사운드 디자인까지 외주 없이 100% 직접 기획하고 제작합니다.
                </p>
              </div>

              <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-zinc-900 border border-amber-400/40 text-amber-400 items-center justify-center shadow-[0_0_12px_rgba(245,158,11,0.25)]">
                <ArrowRight className="w-3.5 h-3.5 animate-flow-arrow" />
              </div>
            </div>

            {/* Step 2: 공채 A급 전문 성우진 매칭 */}
            <div className="relative rounded-xl bg-zinc-950/85 border border-zinc-800/80 hover:border-amber-400/50 p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(245,158,11,0.08)] flex flex-col justify-between group">
              <div>
                <div className="flex items-center justify-between pb-2.5 border-b border-zinc-800/70">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/30 text-amber-300 font-mono text-[11px] font-bold">
                      STEP 02
                    </span>
                    <span className="flex items-center gap-1 text-[11.5px] font-medium text-zinc-300">
                      <Mic className="w-3.5 h-3.5 text-amber-400" />
                      보이스 캐스팅
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                    공채 성우
                  </span>
                </div>

                <div className="h-24 rounded-lg overflow-hidden relative my-3 bg-zinc-900 border border-zinc-800/50">
                  <img
                    src="https://images.unsplash.com/photo-1590602847861-f357a9332bbc?q=80&w=800&auto=format&fit=crop"
                    alt="전문 스튜디오 성우 보이스 레코딩"
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-transparent to-transparent" />
                </div>

                <h4 className="text-[15px] sm:text-[16px] font-bold text-white group-hover:text-amber-400 transition-colors mb-1.5 leading-snug">
                  공채 A급 전문 성우진 매칭
                </h4>
                <p className="text-[11.5px] sm:text-[12px] text-zinc-400 leading-relaxed">
                  KBS, EBS, 투니버스 출신 공채 전문 성우 풀을 직접 보유하여 브랜드에 최적화된 보이스를 연출합니다.
                </p>
              </div>

              <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-zinc-900 border border-amber-400/40 text-amber-400 items-center justify-center shadow-[0_0_12px_rgba(245,158,11,0.25)]">
                <ArrowRight className="w-3.5 h-3.5 animate-flow-arrow" />
              </div>
            </div>

            {/* Step 3: KOBACO 심의 원스톱 대행 */}
            <div className="relative rounded-xl bg-zinc-950/85 border border-zinc-800/80 hover:border-amber-400/50 p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(245,158,11,0.08)] flex flex-col justify-between group">
              <div>
                <div className="flex items-center justify-between pb-2.5 border-b border-zinc-800/70">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/30 text-amber-300 font-mono text-[11px] font-bold">
                      STEP 03
                    </span>
                    <span className="flex items-center gap-1 text-[11.5px] font-medium text-zinc-300">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                      방송 심의
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                    -24 LKFS
                  </span>
                </div>

                <div className="h-24 rounded-lg overflow-hidden relative my-3 bg-zinc-900 border border-zinc-800/50">
                  <img
                    src="https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=800&auto=format&fit=crop"
                    alt="KOBACO 방송광고 음향 마스터링 및 심의"
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-transparent to-transparent" />
                </div>

                <h4 className="text-[15px] sm:text-[16px] font-bold text-white group-hover:text-amber-400 transition-colors mb-1.5 leading-snug">
                  KOBACO 심의 원스톱 대행
                </h4>
                <p className="text-[11.5px] sm:text-[12px] text-zinc-400 leading-relaxed">
                  한국방송광고진흥공사 방송 심의 규격(-24 LKFS) 기준 음향 마스터링 및 심의 신청을 전담 대행합니다.
                </p>
              </div>

              <div className="hidden lg:flex absolute -right-3 top-1/2 -translate-y-1/2 z-20 w-6 h-6 rounded-full bg-zinc-900 border border-amber-400/40 text-amber-400 items-center justify-center shadow-[0_0_12px_rgba(245,158,11,0.25)]">
                <ArrowRight className="w-3.5 h-3.5 animate-flow-arrow" />
              </div>
            </div>

            {/* Step 4: 방송사 송출 청약 연계 */}
            <div className="relative rounded-xl bg-zinc-950/85 border border-zinc-800/80 hover:border-amber-400/50 p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_8px_24px_rgba(245,158,11,0.08)] flex flex-col justify-between group">
              <div>
                <div className="flex items-center justify-between pb-2.5 border-b border-zinc-800/70">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-amber-400/10 border border-amber-400/30 text-amber-300 font-mono text-[11px] font-bold">
                      STEP 04
                    </span>
                    <span className="flex items-center gap-1 text-[11.5px] font-medium text-zinc-300">
                      <Radio className="w-3.5 h-3.5 text-amber-400" />
                      방송 송출
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                    전국 청약
                  </span>
                </div>

                <div className="h-24 rounded-lg overflow-hidden relative my-3 bg-zinc-900 border border-zinc-800/50">
                  <img
                    src="https://images.unsplash.com/photo-1516280440614-37939bbacd81?q=80&w=800&auto=format&fit=crop"
                    alt="라디오 방송국 온에어 및 송출"
                    className="w-full h-full object-cover opacity-80 group-hover:scale-105 group-hover:opacity-100 transition-all duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950/90 via-transparent to-transparent" />
                </div>

                <h4 className="text-[15px] sm:text-[16px] font-bold text-white group-hover:text-amber-400 transition-colors mb-1.5 leading-snug">
                  방송사 송출 청약 연계
                </h4>
                <p className="text-[11.5px] sm:text-[12px] text-zinc-400 leading-relaxed">
                  음원 완성 즉시 지상파 및 교통방송 프라임 타임 라디오 프로그램 청약으로 온에어를 완성합니다.
                </p>
              </div>
            </div>
          </div>
        </div>



        {/* Filter Navigation */}
        <div className="flex flex-wrap items-center gap-2 mt-10 font-apple">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 sm:px-5 sm:py-2.5 text-xs sm:text-sm font-semibold rounded-xl transition-all cursor-pointer ${
                  isActive
                    ? 'bg-amber-400 text-black shadow-md shadow-amber-400/20 font-bold'
                    : 'bg-zinc-900/80 text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-800'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Track Playlist Table (Studio Master Tracklist) */}
        <div className="mt-5 rounded-2xl bg-zinc-950/90 border border-zinc-800/80 overflow-hidden font-apple shadow-lg">
          {/* Table Column Headers */}
          <div className="hidden sm:grid sm:grid-cols-12 gap-4 px-5 py-3.5 bg-zinc-900/60 border-b border-zinc-800/80 text-xs font-mono text-zinc-400 tracking-wider">
            <div className="col-span-7 flex items-center gap-4">
              <span className="w-8 text-center text-zinc-500">#</span>
              <span>라디오 광고 작품 / 광고주</span>
            </div>
            <div className="col-span-3 text-left">구분 & 송출 채널</div>
            <div className="col-span-2 text-right pr-2">듣기 / 재생</div>
          </div>

          {/* Track Rows */}
          <div className="divide-y divide-zinc-800/50">
            {filteredTracks.map((track) => {
              const isSelected = screeningTrack?.id === track.id;

              return (
                <div
                  key={track.id}
                  onClick={() => handleOpenScreening(track)}
                  className={`px-4 sm:px-5 py-4 sm:py-4.5 flex flex-col sm:grid sm:grid-cols-12 gap-3 sm:gap-4 sm:items-center transition-all cursor-pointer group ${
                    isSelected
                      ? 'bg-amber-400/[0.08] border-l-2 border-l-amber-400'
                      : 'hover:bg-zinc-900/50 border-l-2 border-l-transparent'
                  }`}
                >
                  {/* Left: Play Icon / Index & Title */}
                  <div className="sm:col-span-7 flex items-center gap-3.5 sm:gap-4 min-w-0">
                    {/* Index / Play Button */}
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 transition-all bg-zinc-900 group-hover:bg-amber-400 text-zinc-300 group-hover:text-black border border-zinc-800 group-hover:border-amber-400 shadow-sm">
                      <Play className="w-4 h-4 fill-current ml-0.5" />
                    </div>

                    {/* Title & Client */}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm sm:text-base font-bold text-white group-hover:text-amber-400 transition-colors truncate">
                          {track.title}
                        </span>
                      </div>
                      <div className="text-xs text-zinc-400 flex items-center gap-2 mt-0.5 font-apple truncate">
                        <span className="text-amber-300 font-semibold">{track.client}</span>
                        <span className="text-zinc-600">·</span>
                        <span className="text-zinc-300">{track.categoryLabel}</span>
                        <span className="text-zinc-600">·</span>
                        <span className="text-zinc-500 font-mono">{track.mood}</span>
                      </div>
                    </div>
                  </div>

                  {/* Center: Category & Broadcast Channel */}
                  <div className="sm:col-span-3 flex items-center gap-2 text-xs text-zinc-400 font-mono truncate">
                    <span className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800 text-zinc-300 font-apple text-[11px] truncate">
                      {track.broadcastChannel || '공중파 / 라디오'}
                    </span>
                  </div>

                  {/* Right: Duration & Actions */}
                  <div className="sm:col-span-2 flex items-center justify-between sm:justify-end gap-3 text-xs shrink-0">
                    <span className="font-mono text-amber-400 tabular-nums font-semibold px-2 py-0.5 rounded bg-zinc-900/80 border border-zinc-800">
                      {track.duration}
                    </span>

                    {/* Direct Screening Window Trigger Button */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenScreening(track);
                      }}
                      className="px-3 py-1.5 rounded-lg bg-amber-400/15 hover:bg-amber-400 text-amber-300 hover:text-black font-semibold text-xs transition-colors flex items-center gap-1.5 border border-amber-400/30 cursor-pointer"
                    >
                      <Headphones className="w-3.5 h-3.5" />
                      <span>듣기</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Dedicated Audio Screening Window Modal (새로운 창으로 재생 - Matching VideoPortfolio modal design) */}
        {screeningTrack && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fade-in"
            onClick={handleCloseScreening}
          >
            <div 
              className="bg-white rounded-2xl max-w-4xl w-full max-h-[92vh] overflow-y-auto shadow-2xl relative text-zinc-900 border-0 flex flex-col font-apple animate-scale-up"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Modal Header Bar */}
              <div className="flex items-center justify-between p-4 sm:p-5 border-b border-zinc-100 bg-white sticky top-0 z-20 backdrop-blur-md">
                <div className="flex items-center gap-2.5 truncate mr-4">
                  <span className="px-2.5 py-0.5 rounded bg-amber-50 text-[11px] font-mono text-amber-700 uppercase font-bold shrink-0 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-ping" />
                    AUDIO SCREENING
                  </span>
                  <span className="text-xs font-mono text-zinc-500 shrink-0">{screeningTrack.client}</span>
                  <span className="text-zinc-300 shrink-0">|</span>
                  <span className="text-sm font-bold text-zinc-900 truncate">{screeningTrack.title}</span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={(e) => copyTrackLink(screeningTrack, e)}
                    className="px-3 py-1.5 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-700 hover:text-zinc-900 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                    title="이 라디오 광고 공유하기"
                  >
                    {copiedId === screeningTrack.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-700 font-bold">복사됨!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3.5 h-3.5 text-zinc-600" />
                        <span>공유하기</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={handleCloseScreening}
                    className="p-1.5 text-zinc-400 hover:text-zinc-900 rounded-lg hover:bg-zinc-100 transition-colors cursor-pointer shrink-0"
                    aria-label="닫기"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Real Audio Player Screen / Studio Broadcast Console - Centered Horizontally & Vertically */}
              <div className="relative bg-zinc-950 text-white rounded-xl sm:rounded-2xl p-4 sm:p-5 m-3 sm:m-5 shadow-2xl border border-zinc-800 overflow-hidden select-none flex flex-col justify-center items-center gap-2.5">
                {/* Hidden HTML5 Audio Element connected to uploaded file */}
                {screeningTrack.audioUrl && (
                  <audio
                    ref={modalAudioRef}
                    src={screeningTrack.audioUrl}
                    preload="auto"
                    onTimeUpdate={(e) => {
                      setModalTime(e.currentTarget.currentTime);
                    }}
                    onLoadedMetadata={(e) => {
                      const dur = e.currentTarget.duration;
                      if (dur && !isNaN(dur) && dur > 0) {
                        setModalDuration(dur);
                      }
                    }}
                    onEnded={() => {
                      setIsModalPlaying(false);
                      setModalTime(0);
                    }}
                    onPlay={() => setIsModalPlaying(true)}
                    onPause={() => setIsModalPlaying(false)}
                  />
                )}

                {/* Subtle Studio Lighting Glow Accents */}
                <div className="absolute -top-20 -left-20 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

                {/* Top Deck Info Ribbon - Centered (ON AIR button removed) */}
                <div className="relative z-10 flex flex-wrap items-center justify-center gap-3 pb-2 border-b border-zinc-800/80 text-xs font-mono text-zinc-400 w-full text-center">
                  <span className="flex items-center gap-1.5 text-zinc-300">
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                    <span>KOBACO -24 LKFS 방송 표준 마스터링</span>
                  </span>
                  <span className="text-zinc-600">·</span>
                  <span>STEREO 48kHz / 24bit</span>
                </div>

                {/* Center Audio Visualizer Screen - Slim Compact Height & Centered */}
                <div className="my-1 sm:my-1.5 relative z-10 w-full">
                  {/* Dynamic Frequency Waveform Canvas */}
                  <div 
                    onClick={handleModalSeek}
                    className="h-8 sm:h-9 bg-zinc-900/90 rounded-lg sm:rounded-xl border border-zinc-800 p-1 sm:p-1.5 overflow-hidden relative cursor-pointer hover:border-amber-400/50 transition-colors group/wave shadow-inner w-full"
                    title="클릭하여 원하는 구간으로 이동"
                  >
                    <canvas
                      ref={modalCanvasRef}
                      width={900}
                      height={36}
                      className="w-full h-full object-cover"
                    />

                    {/* Glowing Playback Progress Cursor Line */}
                    <div
                      className="absolute top-0 bottom-0 w-1 bg-amber-400 shadow-[0_0_8px_#f59e0b] pointer-events-none transition-all duration-75"
                      style={{ left: `${modalProgressPercent}%` }}
                    />

                    {/* Hover Seek Hint */}
                    <div className="absolute bottom-1 right-2 px-1.5 py-0.2 rounded bg-black/70 text-[9px] font-mono text-zinc-400 pointer-events-none opacity-0 group-hover/wave:opacity-100 transition-opacity">
                      구간 이동
                    </div>
                  </div>

                  {/* Scrubber Time Bar */}
                  <div 
                    onClick={handleModalSeek}
                    className="mt-1.5 w-full h-1.5 bg-zinc-800/80 rounded-full overflow-hidden cursor-pointer relative hover:h-2 transition-all"
                  >
                    <div 
                      className="h-full bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 rounded-full shadow-[0_0_6px_rgba(251,191,36,0.6)]"
                      style={{ width: `${modalProgressPercent}%` }}
                    />
                  </div>
                </div>

                {/* Deck Controls Cluster - 30% Reduced Vertical Ratio & Centered */}
                <div className="relative z-10 pt-2 border-t border-zinc-800/80 flex flex-wrap items-center justify-center gap-3 sm:gap-6 font-apple w-full">
                  {/* Playback Controls (Play/Pause, Replay, Time Readout) */}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={toggleModalPlay}
                      className="px-3.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs flex items-center justify-center gap-1.5 shadow-sm shadow-amber-400/20 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
                    >
                      {isModalPlaying ? (
                        <>
                          <Pause className="w-3.5 h-3.5 fill-black" />
                          <span>일시 정지</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 fill-black ml-0.5" />
                          <span>재생하기</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={handleModalReplay}
                      className="w-7.5 h-7.5 p-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                      title="처음부터 다시 재생"
                      aria-label="처음부터 다시 재생"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-1 text-xs font-mono px-1.5 text-zinc-400">
                      <span className="text-amber-400 font-bold tabular-nums">{formatAudioTime(modalTime)}</span>
                      <span className="text-zinc-600">/</span>
                      <span className="tabular-nums">{formatAudioTime(modalDuration)}</span>
                    </div>
                  </div>

                  <span className="text-zinc-700 hidden sm:inline">|</span>

                  {/* Volume Control - Centered */}
                  <div className="flex items-center gap-2 bg-zinc-900/90 px-2.5 py-1 rounded-lg border border-zinc-800/90 shadow-inner">
                    <button
                      type="button"
                      onClick={toggleModalMute}
                      className="w-6 h-6 rounded-md bg-zinc-800 hover:bg-zinc-700 text-amber-400 flex items-center justify-center transition-colors cursor-pointer"
                      title={isModalMuted ? '음소거 해제' : '음소거'}
                      aria-label="음소거 토글"
                    >
                      {isModalMuted || modalVolume === 0 ? (
                        <VolumeX className="w-3.5 h-3.5 text-red-400" />
                      ) : modalVolume < 0.4 ? (
                        <Volume1 className="w-3.5 h-3.5 text-amber-400" />
                      ) : (
                        <Volume2 className="w-3.5 h-3.5 text-amber-400" />
                      )}
                    </button>

                    <div className="relative flex items-center group/vol">
                      <div
                        onClick={handleVolumeBarClick}
                        className="w-16 sm:w-24 h-1.5 bg-zinc-800 rounded-full overflow-hidden cursor-pointer relative hover:h-2 transition-all border border-zinc-700/60"
                        title="클릭하여 볼륨 조절"
                      >
                        <div
                          className="h-full bg-gradient-to-r from-amber-500 to-amber-400 rounded-full transition-all duration-75 shadow-[0_0_6px_rgba(245,158,11,0.5)]"
                          style={{ width: `${isModalMuted ? 0 : Math.round(modalVolume * 100)}%` }}
                        />
                      </div>

                      <input
                        type="range"
                        min="0"
                        max="1"
                        step="0.01"
                        value={isModalMuted ? 0 : modalVolume}
                        onChange={(e) => handleModalVolumeChange(parseFloat(e.target.value))}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        aria-label="볼륨 조절 슬라이더"
                      />
                    </div>

                    <span className="text-[10px] font-mono tabular-nums font-bold text-amber-400 w-6 text-right">
                      {isModalMuted || modalVolume === 0 ? (
                        <span className="text-red-400">OFF</span>
                      ) : (
                        `${Math.round(modalVolume * 100)}%`
                      )}
                    </span>
                  </div>
                </div>
              </div>

              {/* Project Metadata & Narrative Scripts Area (Clean, Professional White Background matching Video Reel) */}
              <div className="p-6 sm:p-8 space-y-6 bg-white">
                {/* Title & Metadata Header */}
                <div className="pb-5 border-b border-zinc-100">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-500 font-mono mb-2">
                    <span className="text-amber-600 font-bold">{screeningTrack.client}</span>
                    <span>·</span>
                    <span>{screeningTrack.categoryLabel}</span>
                    <span>·</span>
                    <span>{screeningTrack.year}년 제작</span>
                    <span>·</span>
                    <span className="flex items-center gap-1 text-zinc-600">
                      <Clock className="w-3.5 h-3.5 text-amber-500" />
                      {screeningTrack.duration} (-24 LKFS 방송 규격)
                    </span>
                    <span>·</span>
                    <span className="text-zinc-600">{screeningTrack.broadcastChannel}</span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-extrabold text-zinc-900 leading-tight">
                    {screeningTrack.title}
                  </h3>

                  {screeningTrack.badge && (
                    <span className="inline-flex items-center gap-1.5 mt-2.5 px-2.5 py-1 rounded bg-amber-50 text-xs font-mono text-amber-800 font-semibold border border-amber-200/60">
                      <Award className="w-3.5 h-3.5 text-amber-600" />
                      {screeningTrack.badge}
                    </span>
                  )}
                </div>

                {/* Verbatim Script & Lyrics Box */}
                <div>
                  <div className="flex items-center gap-2 mb-2.5">
                    <div className="w-6 h-6 rounded-md bg-amber-100 text-amber-800 flex items-center justify-center">
                      <FileText className="w-3.5 h-3.5" />
                    </div>
                    <h4 className="text-sm sm:text-base font-bold text-zinc-900">전체 나레이션 & 가사 대본</h4>
                  </div>

                  <div className="p-4 sm:p-5 rounded-xl bg-zinc-50 border border-zinc-200 text-zinc-800 text-sm leading-relaxed font-normal whitespace-pre-line shadow-xs">
                    {screeningTrack.fullScript || screeningTrack.scriptSnippet}
                  </div>
                </div>


                {/* Footer Action Bar */}
                <div className="pt-5 border-t border-zinc-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <button
                    type="button"
                    onClick={(e) => copyTrackLink(screeningTrack, e)}
                    className="px-4 py-2.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 text-xs sm:text-sm font-semibold flex items-center gap-2 border border-amber-200/80 transition-colors cursor-pointer"
                  >
                    {copiedId === screeningTrack.id ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-600" />
                        <span className="text-emerald-700 font-bold">공유 링크가 복사되었습니다!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-4 h-4 text-amber-700" />
                        <span>이 라디오 광고 공유하기 (링크 복사)</span>
                      </>
                    )}
                  </button>

                  <div className="flex items-center justify-end">
                    <button
                      type="button"
                      onClick={handleCloseScreening}
                      className="px-5 py-2.5 text-xs sm:text-sm font-medium text-zinc-700 hover:text-zinc-900 rounded-xl bg-zinc-100 hover:bg-zinc-200 transition-colors cursor-pointer"
                    >
                      닫기
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
