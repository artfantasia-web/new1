import React, { useState } from 'react';
import { NOTICES } from '../data/content';
import { NoticeItem } from '../types';
import { Pin, Search, Eye, Calendar, X, Share2, Check } from 'lucide-react';

export const NoticeSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeNotice, setActiveNotice] = useState<NoticeItem | null>(null);
  const [copied, setCopied] = useState(false);

  const categories = ['all', '공지', '제작소식', '보도자료', '수상소식'];

  const filteredNotices = NOTICES.filter((item) => {
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesQuery = searchQuery === '' ||
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.content.some(c => c.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCat && matchesQuery;
  });

  const handleShare = (item: NoticeItem) => {
    navigator.clipboard.writeText(`${window.location.origin}#notice-${item.id}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="notice" className="py-24 border-b border-zinc-800 bg-[#09090b]">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-zinc-800 animate-header-reveal">
          <div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
              공지사항 & 미디어 소식
            </h2>
          </div>
          <p className="text-sm sm:text-base text-zinc-400 max-w-md leading-relaxed">
            아트판타지아의 최신 스튜디오 확장, 주요 광고제 수상, 방송광고 프로모션 및 보도자료를 전해드립니다.
          </p>
        </div>

        {/* Filter Controls & Search */}
        <div className="mt-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 p-1 bg-zinc-950 border border-zinc-800 rounded-lg overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-amber-400 text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                {cat === 'all' ? '전체 보기' : cat}
              </button>
            ))}
          </div>

          <div className="relative min-w-[260px]">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="공지 및 소식 검색..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
            />
          </div>
        </div>

        {/* Notice List Table */}
        <div className="mt-6 rounded-lg bg-zinc-950 border border-zinc-800/80 overflow-hidden">
          <div className="hidden sm:grid grid-cols-12 gap-4 px-6 py-3 bg-zinc-900/60 border-b border-zinc-800 text-[11px] font-mono text-zinc-400 uppercase tracking-wider">
            <div className="col-span-2">카테고리</div>
            <div className="col-span-7">제목</div>
            <div className="col-span-2 text-right">등록일</div>
            <div className="col-span-1 text-right">조회</div>
          </div>

          <div className="divide-y divide-zinc-800/60">
            {filteredNotices.length === 0 ? (
              <div className="p-12 text-center text-zinc-500 text-xs font-mono">
                검색 조건에 일치하는 공지사항이 없습니다.
              </div>
            ) : (
              filteredNotices.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setActiveNotice(item)}
                  className="group cursor-pointer p-4 sm:px-6 sm:py-4 flex flex-col sm:grid sm:grid-cols-12 gap-2 sm:gap-4 items-start sm:items-center hover:bg-zinc-900/40 transition-colors"
                >
                  {/* Category & Badge */}
                  <div className="sm:col-span-2 flex items-center gap-2">
                    {item.pinned && (
                      <span className="p-1 rounded bg-amber-400/10 text-amber-400">
                        <Pin className="w-3 h-3 rotate-45" />
                      </span>
                    )}
                    <span className="text-xs font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
                      {item.category}
                    </span>
                  </div>

                  {/* Title */}
                  <div className="sm:col-span-7">
                    <h4 className="text-sm font-semibold text-white group-hover:text-amber-400 transition-colors line-clamp-1">
                      {item.title}
                    </h4>
                  </div>

                  {/* Date */}
                  <div className="sm:col-span-2 sm:text-right text-xs font-mono text-zinc-500 flex items-center sm:justify-end gap-1">
                    <Calendar className="w-3 h-3 text-zinc-600 sm:hidden" />
                    <span>{item.date}</span>
                  </div>

                  {/* Views */}
                  <div className="sm:col-span-1 sm:text-right text-xs font-mono text-zinc-500 flex items-center sm:justify-end gap-1">
                    <Eye className="w-3 h-3 text-zinc-600 sm:hidden" />
                    <span>{item.views}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Notice Reading Modal */}
        {activeNotice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm">
            <div className="bg-white rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[85vh] overflow-y-auto text-zinc-900 border-0">
              <div className="flex items-center justify-between pb-4 border-b border-zinc-100">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono text-amber-700 font-bold">[{activeNotice.category}]</span>
                  <span className="text-xs text-zinc-400 font-mono">{activeNotice.date}</span>
                </div>
                <button
                  onClick={() => setActiveNotice(null)}
                  className="p-1.5 text-zinc-400 hover:text-zinc-900 rounded-lg hover:bg-zinc-100 transition-colors"
                  aria-label="닫기"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-6 space-y-6">
                <div>
                  <h3 className="text-xl sm:text-2xl font-bold text-zinc-900 leading-snug">
                    {activeNotice.title}
                  </h3>
                  <div className="mt-2 text-xs font-mono text-zinc-500 flex items-center gap-4">
                    <span>작성: {activeNotice.author}</span>
                    <span>조회수: {activeNotice.views}회</span>
                  </div>
                </div>

                <div className="space-y-4 text-sm text-zinc-700 leading-relaxed font-sans border-y border-zinc-100 py-6">
                  {activeNotice.content.map((p, idx) => (
                    <p key={idx}>{p}</p>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-100 flex items-center justify-between">
                <button
                  onClick={() => handleShare(activeNotice)}
                  className="px-3 py-1.5 text-xs font-mono text-zinc-600 hover:text-zinc-900 rounded-lg bg-zinc-100 hover:bg-zinc-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                  <span>{copied ? '링크 복사됨' : '공유하기'}</span>
                </button>

                <button
                  onClick={() => setActiveNotice(null)}
                  className="px-4 py-2 text-xs font-semibold text-black bg-amber-400 hover:bg-amber-300 rounded-lg cursor-pointer"
                >
                  확인 완료
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
