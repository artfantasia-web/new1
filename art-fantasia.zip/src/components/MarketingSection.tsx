import React, { useState } from 'react';
import { MARKETING_CASES } from '../data/content';
import { MarketingCase } from '../types';
import { TrendingUp, Target, Share2, Users, ArrowUpRight, CheckCircle2, BarChart3 } from 'lucide-react';

interface MarketingSectionProps {
  onOpenInquiry: () => void;
}

export const MarketingSection: React.FC<MarketingSectionProps> = ({ onOpenInquiry }) => {
  const [selectedCase, setSelectedCase] = useState<MarketingCase | null>(null);

  const pillars = [
    {
      num: '01',
      title: '통합 디지털 캠페인 (IMC)',
      sub: 'INTEGRATED MARKETING CAMPAIGN',
      desc: '영상, 라디오 CM, 옥외광고, 온라인 퍼포먼스를 단일한 메시지 아키텍처로 설계하여 소비자 동선을 전방위 장악합니다.',
      icon: <Target className="w-5 h-5" />,
      features: ['브랜드 포지셔닝 전략', '미디어 믹스 최적화', '온·오프라인 크로스 채널 집행']
    },
    {
      num: '02',
      title: '퍼포먼스 & 데이터 마케팅',
      sub: 'ROAS & CONVERSION OPTIMIZATION',
      desc: '정밀 오디언스 타깃팅과 크리에이티브 소재 다변화 A/B 테스트로 고객 획득 비용(CPA)을 낮추고 매출 전환을 극대화합니다.',
      icon: <TrendingUp className="w-5 h-5" />,
      features: ['메타 / 구글 / 네이버 SA·DA', '실시간 대시보드 리포팅', '퍼널 단계별 리타깃팅']
    },
    {
      num: '03',
      title: '바이럴 숏폼 & SNS 팩토리',
      sub: 'SHORT-FORM & VIRAL LAB',
      desc: '틱톡, 유튜브 쇼츠, 인스타그램 릴스 알고리즘을 꿰뚫는 후킹 사운드와 비주얼 연출로 자발적인 바이럴 확산을 유도합니다.',
      icon: <Share2 className="w-5 h-5" />,
      features: ['주간 숏폼 트렌드 분석', '중독성 징글/오디오 챌린지', 'UGC(사용자 제작 콘텐츠) 유도']
    },
    {
      num: '04',
      title: '인플루언서 & 브랜디드 엔터',
      sub: 'CREATOR COLLABORATION',
      desc: '단순 PPL을 넘어 브랜드 철학을 흥미진진한 콘텐츠로 승화시키는 톱 크리에이터 매칭 및 오리지널 웹 예능을 제작합니다.',
      icon: <Users className="w-5 h-5" />,
      features: ['카테고리별 검증된 크리에이터 풀', '고감도 영상 연출팀 투입', '커머스 프로모션 연계']
    }
  ];

  return (
    <section id="marketing" className="py-24 border-b border-zinc-800 bg-[#09090b] relative">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-zinc-800 animate-header-reveal">
          <div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
              마케팅 사업: 제작에서 전환까지
            </h2>
          </div>
          <p className="text-sm sm:text-base text-zinc-400 max-w-md leading-relaxed">
            좋은 콘텐츠는 시작일 뿐입니다. 아트판타지아 마케팅 사업부는 제작된 비주얼과 오디오가 실질적인 매출과 유입으로 이어지도록 설계합니다.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
          {pillars.map((p, idx) => (
            <div
              key={idx}
              className="p-6 rounded-lg bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-xl font-mono font-extrabold text-amber-400">{p.num}</span>
                  <div className="w-8 h-8 rounded bg-zinc-900 flex items-center justify-center text-zinc-300 border border-zinc-800">
                    {p.icon}
                  </div>
                </div>

                <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider block mb-1">
                  {p.sub}
                </span>
                <h3 className="text-base font-bold text-white mb-2">{p.title}</h3>
                <p className="text-xs text-zinc-400 leading-relaxed mb-4">{p.desc}</p>
              </div>

              <div className="space-y-1.5 pt-4 border-t border-zinc-900">
                {p.features.map((f, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-[11px] text-zinc-400 font-mono">
                    <span className="text-amber-400">·</span>
                    <span>{f}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Quantified Real Case Studies Showcase */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-6">
            <div>
              <span className="text-xs font-mono text-amber-400 uppercase">PROVEN BUSINESS OUTCOMES</span>
              <h3 className="text-xl sm:text-2xl font-bold text-white mt-1">
                데이터로 증명된 캠페인 성공 사례
              </h3>
            </div>
            <span className="text-xs font-mono text-zinc-400 hidden sm:inline">
              QUANTIFIED METRICS
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {MARKETING_CASES.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedCase(item)}
                className="group cursor-pointer p-6 sm:p-8 rounded-lg bg-zinc-950 border border-zinc-800/80 hover:border-zinc-700 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3 text-xs font-mono">
                    <span className="text-zinc-400">{item.client}</span>
                    <span className="text-zinc-400">{item.period}</span>
                  </div>

                  <h4 className="text-base sm:text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                    {item.title}
                  </h4>

                  <p className="mt-2 text-xs text-zinc-400 leading-relaxed">
                    {item.summary}
                  </p>
                </div>

                {/* Big Metric Box */}
                <div className="mt-6 pt-6 border-t border-zinc-900 flex items-center justify-between">
                  <div>
                    <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono tabular-nums">
                      {item.metricHighlight}
                    </div>
                    <div className="text-[11px] text-zinc-400 font-mono mt-0.5">
                      {item.metricLabel}
                    </div>
                  </div>

                  <span className="text-xs font-mono text-zinc-400 group-hover:text-white flex items-center gap-1 transition-colors">
                    <span>자세히 보기</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Case Study Detail Modal */}
        {selectedCase && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm">
            <div className="bg-zinc-950 border border-zinc-700 rounded-lg max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative">
              <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
                <span className="text-xs font-mono text-amber-400 uppercase">
                  CASE STUDY ARCHIVE // {selectedCase.pillarLabel}
                </span>
                <button
                  onClick={() => setSelectedCase(null)}
                  className="p-1 text-zinc-400 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="py-6 space-y-6">
                <div>
                  <span className="text-xs text-zinc-400 font-mono">{selectedCase.client} · {selectedCase.period}</span>
                  <h3 className="text-xl font-bold text-white mt-1">{selectedCase.title}</h3>
                  <p className="text-sm text-zinc-300 mt-2 leading-relaxed">{selectedCase.summary}</p>
                </div>

                <div className="p-4 rounded bg-zinc-900 border border-zinc-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono text-zinc-400">{selectedCase.metricLabel}</span>
                    <div className="text-3xl font-extrabold text-amber-400 font-mono tabular-nums mt-1">
                      {selectedCase.metricHighlight}
                    </div>
                  </div>
                  <BarChart3 className="w-8 h-8 text-amber-400/40" />
                </div>

                <div>
                  <h4 className="text-xs font-mono text-amber-400 uppercase tracking-wider mb-2">실행 핵심 전략</h4>
                  <div className="space-y-2">
                    {selectedCase.strategies.map((strat, idx) => (
                      <div key={idx} className="p-3 rounded bg-zinc-900/60 border border-zinc-800 text-xs text-zinc-300 flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                        <span>{strat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-2">
                  {selectedCase.tags.map((t, idx) => (
                    <span key={idx} className="text-xs font-mono text-zinc-400 bg-zinc-900 px-2 py-0.5 rounded">
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-zinc-800 flex justify-end gap-3">
                <button
                  onClick={() => setSelectedCase(null)}
                  className="px-4 py-2 text-xs text-zinc-300 hover:text-white rounded bg-zinc-800"
                >
                  닫기
                </button>
                <button
                  onClick={() => {
                    setSelectedCase(null);
                    onOpenInquiry();
                  }}
                  className="px-4 py-2 text-xs font-bold text-black bg-amber-400 hover:bg-amber-300 rounded flex items-center gap-1.5"
                >
                  <span>마케팅 캠페인 문의</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Marketing Architecture Strip */}
        <div className="mt-14 p-8 rounded-lg bg-zinc-950 border border-zinc-800/80">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <span className="text-xs font-mono text-amber-400">DATA-DRIVEN METHODOLOGY</span>
              <h4 className="text-xl font-bold text-white mt-1">
                영상·오디오 제작과 디지털 마케팅의 결합 패키지
              </h4>
              <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
                제작 따로, 마케팅 따로 집행할 때 발생하는 커뮤니케이션 비용과 광고 소재 미스매치를 없애고,
                최적화된 미디어 플래닝으로 집행 예산 대비 최대의 ROI를 실현합니다.
              </p>
            </div>
            <button
              onClick={onOpenInquiry}
              className="px-6 py-3.5 text-xs font-bold text-black bg-amber-400 hover:bg-amber-300 rounded whitespace-nowrap transition-colors flex items-center justify-center gap-2 cursor-pointer self-start md:self-auto"
            >
              <span>통합 마케팅 제안서 요청</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
