import React, { useState } from 'react';
import { 
  Play, 
  Pause, 
  Download, 
  Copy, 
  Check, 
  ShieldCheck, 
  Heart, 
  Sparkles, 
  Info, 
  ExternalLink, 
  Send,
  FileCheck,
  Award,
  Video
} from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';

interface AfanMusicSectionProps {
  onOpenInquiry?: () => void;
}

interface AfanTrack {
  id: string;
  title: string;
  artist: string;
  genre: string;
  mood: string;
  bpm: number;
  duration: string;
  theme: 'acoustic' | 'ambient' | 'cinematic' | 'jingle' | 'corporate';
  description: string;
  featuredNote?: string;
  tags: string[];
}

const AFAN_TRACKS: AfanTrack[] = [
  {
    id: 'track-01',
    title: '붕어빵',
    artist: '아판뮤직',
    genre: '어쿠스틱 포크',
    mood: '따뜻함 · 일상 · 소소한 행복',
    bpm: 88,
    duration: '03:15',
    theme: 'acoustic',
    description: '추운 겨울날 김이 모락모락 피어오르는 붕어빵처럼, 평범한 일상의 따뜻한 온기를 잔잔한 기타와 휘슬 멜로디로 담아낸 대표 감성 트랙.',
    featuredNote: '유튜브 브이로그 & 일상 콘텐츠 추천 BGM',
    tags: ['포크', '어쿠스틱기타', '브이로그', '따뜻한', '힐링']
  },
  {
    id: 'track-02',
    title: '우린 마치',
    artist: '아판뮤직',
    genre: '인디 감성 팝',
    mood: '서정적 · 풋풋함 · 여운',
    bpm: 96,
    duration: '03:42',
    theme: 'acoustic',
    description: '서로를 조심스레 알아가는 순간의 떨림과 설렘을 어쿠스틱 피아노와 스트링의 감미로운 조화로 완성한 인디 감성 트랙.',
    tags: ['인디팝', '피아노', '감성', '로맨스', '서정']
  },
  {
    id: 'track-03',
    title: 'Rain is falling',
    artist: '아판뮤직',
    genre: '재즈 & 감성 BGM',
    mood: '차분함 · 사색 · 비 오는 날',
    bpm: 76,
    duration: '03:28',
    theme: 'ambient',
    description: '유리창을 토닥이는 빗소리와 함께 은은하게 울려 퍼지는 재즈 피아노 터치가 마음을 차분하게 정리해 주는 센티멘털 트랙.',
    featuredNote: '공부·카페·사색 콘텐츠 추천 BGM',
    tags: ['재즈피아노', '로파이', '비오는날', '휴식', '카페']
  },
  {
    id: 'track-04',
    title: '잘 가요 로맨스 (Goodbye romance)',
    artist: '아판뮤직',
    genre: '시티팝 & 로맨스',
    mood: '레트로 · 세련됨 · 낭만',
    bpm: 110,
    duration: '03:36',
    theme: 'jingle',
    description: '도시의 네온사인 아래 지나간 계절의 사랑을 쿨하고 경쾌한 그루브와 몽환적인 신스 사운드로 풀어낸 모던 시티팝.',
    tags: ['시티팝', '신스웨이브', '레트로', '그루브', '드라이브']
  },
  {
    id: 'track-05',
    title: '찬란, 봄',
    artist: '아판뮤직',
    genre: '피아노 연주곡',
    mood: '화사함 · 설렘 · 시작',
    bpm: 84,
    duration: '02:58',
    theme: 'acoustic',
    description: '봄꽃이 피어나듯 맑고 영롱한 피아노 선율이 새로운 출발과 희망찬 설렘을 수채화처럼 수놓는 힐링 피아노 트랙.',
    featuredNote: '학생 영상 과제 및 시작 테마 추천 BGM',
    tags: ['피아노연주', '봄', '희망', '청춘', '새출발']
  },
  {
    id: 'track-06',
    title: '오래의 부탁',
    artist: '아판뮤직',
    genre: '시네마틱 오케스트라',
    mood: '웅장함 · 서사 · 감동',
    bpm: 72,
    duration: '04:12',
    theme: 'cinematic',
    description: '시간을 건너 전하는 진심 어린 이야기를 깊은 첼로 독주와 점진적으로 고조되는 오케스트라 스트링으로 형상화한 시네마틱 트랙.',
    featuredNote: '단편영화 & 드라마 공모전 추천 BGM',
    tags: ['영화음악', '오케스트라', '스트링', '감동', '드라마']
  },
  {
    id: 'track-07',
    title: '조수간만의 차 (Song of a wave)',
    artist: '아판뮤직',
    genre: '앰비언트 & 칠아웃',
    mood: '몽환적 · 고요함 · 바다',
    bpm: 68,
    duration: '04:05',
    theme: 'ambient',
    description: '밀려왔다 밀려가는 파도의 호흡을 앰비언트 패드와 신비로운 공간계 사운드로 재현한 고품격 명상 힐링 음악.',
    tags: ['앰비언트', '바다', '명상', '수면', '힐링사운드']
  },
  {
    id: 'track-08',
    title: '블루 포레스트 (Blue Forest)',
    artist: '아판뮤직',
    genre: 'CF & 시네마틱 BGM',
    mood: '자연의 신비 · 장엄함 · 에코',
    bpm: 104,
    duration: '03:18',
    theme: 'cinematic',
    description: '삼성 The Sero 아프리카 4K 편 CF에 삽입되어 큰 호응을 얻었던 공식 트랙. 대자연의 광활함과 생명력을 역동적으로 그려낸 명작.',
    featuredNote: '★ 삼성 The Sero 아프리카 4K 편 CF 공식 테마',
    tags: ['삼성CF', '대자연', '다큐멘터리', '모던클래식', '영상미']
  },
  {
    id: 'track-09',
    title: '바램',
    artist: '아판뮤직',
    genre: '어쿠스틱 발라드',
    mood: '위로 · 따뜻한 포옹 · 안식',
    bpm: 78,
    duration: '03:30',
    theme: 'acoustic',
    description: '지친 하루 끝에 건네는 묵묵한 위로처럼, 담담한 어쿠스틱 기타 리프 위에 스며드는 현악의 따스한 온기.',
    tags: ['위로', '발라드', '어쿠스틱', '감성', '휴식']
  },
  {
    id: 'track-10',
    title: '청춘(靑春) "오늘 밤 나를 데려가줘!"',
    artist: '아판뮤직',
    genre: '인디 록 & 에너지',
    mood: '질주 · 열정 · 청춘의 패기',
    bpm: 132,
    duration: '03:22',
    theme: 'jingle',
    description: '뜨거운 청춘의 밤, 한계를 넘어 질주하는 젊은 에너지를 폭발적인 일렉기타 리프와 드럼 비트로 터뜨린 인디 록 트랙.',
    featuredNote: '청춘 영화 & 청년 공모전 영상 추천 BGM',
    tags: ['인디록', '청춘', '열정', '질주', '페스티벌']
  },
  {
    id: 'track-11',
    title: '"딸을 향한 아빠의 노래"',
    artist: '아판뮤직',
    genre: '감성 포크 발라드',
    mood: '가족애 · 뭉클함 · 사랑',
    bpm: 75,
    duration: '04:02',
    theme: 'acoustic',
    description: '세상 그 무엇보다 소중한 딸의 성장을 바라보는 아빠의 진솔한 마음을 어쿠스틱 악기 편곡으로 애틋하게 담아낸 가족 감동 송.',
    tags: ['가족', '감동', '아빠와딸', '눈물', '어쿠스틱']
  },
  {
    id: 'track-12',
    title: '"유리벽 너머" OST',
    artist: '아판뮤직',
    genre: '영화음악 / 오리지널 스코어',
    mood: '미스터리 · 긴장감 · 심리 드라마',
    bpm: 80,
    duration: '03:54',
    theme: 'cinematic',
    description: '유리벽 너머의 진실을 마주하는 인물의 내면적 갈등을 팽팽한 서스펜스와 드라마틱한 전조로 이끌어가는 정통 영화 음악.',
    featuredNote: '독립영화 & 시나리오 공모전 최적화 BGM',
    tags: ['영화OST', '서스펜스', '심리극', '시네마틱', '오케스트라']
  },
  {
    id: 'track-13',
    title: "JiYoon(지윤) 'TinMoon'",
    artist: '아판뮤직',
    genre: '드림팝 뮤직비디오',
    mood: '몽환적 · 달빛 · 감각적',
    bpm: 98,
    duration: '03:45',
    theme: 'ambient',
    description: '차갑지만 신비로운 달빛의 텍스처를 몽환적인 드림팝 보컬과 신스 사운드로 직조해낸 감각적인 뮤직비디오 타이틀곡.',
    tags: ['드림팝', '뮤직비디오', '몽환', '신스팝', '감각적']
  },
  {
    id: 'track-14',
    title: '새벽 항해',
    artist: '아판뮤직',
    genre: '핑거스타일 어쿠스틱',
    mood: '새벽 감성 · 고요한 도전',
    bpm: 90,
    duration: '03:10',
    theme: 'acoustic',
    description: '모두가 잠든 고요한 새벽, 나만의 꿈을 향해 닻을 올리는 첫 발걸음을 핑거스타일 기타 테크닉으로 맑고 정갈하게 연주한 트랙.',
    tags: ['핑거스타일', '기타', '새벽', '출항', '꿈']
  }
];

export const AfanMusicSection: React.FC<AfanMusicSectionProps> = ({ onOpenInquiry }) => {
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [copiedTrackId, setCopiedTrackId] = useState<string | null>(null);
  const [globalCopied, setGlobalCopied] = useState(false);
  const [selectedGenre, setSelectedGenre] = useState<string>('all');

  const genres = ['all', '어쿠스틱 포크', '피아노 연주곡', '재즈 & 감성 BGM', '시네마틱 오케스트라', '시티팝 & 로맨스', '인디 록 & 에너지'];

  const filteredTracks = selectedGenre === 'all' 
    ? AFAN_TRACKS 
    : AFAN_TRACKS.filter(t => t.genre.includes(selectedGenre) || t.tags.includes(selectedGenre));

  const handlePlayToggle = (track: AfanTrack) => {
    if (playingTrackId === track.id) {
      audioEngine.stop();
      setPlayingTrackId(null);
    } else {
      audioEngine.playTheme(track.theme);
      setPlayingTrackId(track.id);
    }
  };

  const handleCopyCitation = (trackTitle: string, id: string) => {
    const citation = `🎵 BGM 출처: 아트판타지아(ArtFantasia) 아판뮤직 - "${trackTitle}" (https://artfantasia.co.kr)`;
    navigator.clipboard.writeText(citation).then(() => {
      setCopiedTrackId(id);
      setTimeout(() => setCopiedTrackId(null), 2500);
    });
  };

  const handleCopyGlobalCitation = () => {
    const citation = `🎵 BGM 출처: 아트판타지아(ArtFantasia) 아판뮤직 (https://artfantasia.co.kr)`;
    navigator.clipboard.writeText(citation).then(() => {
      setGlobalCopied(true);
      setTimeout(() => setGlobalCopied(false), 2500);
    });
  };

  return (
    <section className="py-16 sm:py-24 border-b border-zinc-800 bg-[#09090b] text-white">
      <div className="max-w-7xl mx-auto px-6 sm:px-8">
        
        {/* Header Section */}
        <div className="max-w-4xl mb-12 sm:mb-16 animate-header-reveal">


          <div className="space-y-2 mb-4">
            <span className="text-sm sm:text-base text-amber-400 font-bold block tracking-normal">
              모든 창작자와 청년들의 빛나는 꿈을 응원합니다
            </span>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
              아판뮤직(Afan Music)
            </h1>
          </div>

          <p className="text-sm sm:text-base text-zinc-300 leading-relaxed font-normal pt-1 max-w-3xl">
            아판뮤직은 아트판타지아가 제작하는 감성 오리지널 음원 브랜드입니다.
            음원 판매의 상업적 목적이 아닌, 비상업적 용도(개인 소장, 공모전 출품, 유튜브 영상 BGM)로 누구나 자유롭게 활용하실 수 있도록 열려 있는 따뜻한 음악 공간입니다.
          </p>
        </div>

        {/* Official Copyright & Free Usage Policy Banner (Based on artfantasia.co.kr/286) */}
        <div className="mb-14 p-6 sm:p-8 rounded-2xl bg-zinc-950 border border-zinc-800 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-80 h-80 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-zinc-800">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/20 text-xs font-mono text-emerald-400 font-bold mb-2">
                <FileCheck className="w-3.5 h-3.5" />
                <span>OFFICIAL COPYRIGHT GUIDELINE (게시글 #286 공지 기준)</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                아판뮤직 무료 음악 사용 & 저작권 원칙 안내
              </h2>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <a
                href="https://artfantasia.co.kr/286"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs font-semibold text-zinc-200 transition-colors"
              >
                <span>원문 공지글 보기 (#286)</span>
                <ExternalLink className="w-3.5 h-3.5 text-zinc-400" />
              </a>
              <button
                onClick={handleCopyGlobalCitation}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs shadow-md transition-all cursor-pointer"
              >
                {globalCopied ? <Check className="w-3.5 h-3.5 text-black" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{globalCopied ? '출처 복사 완료!' : '유튜브 출처 양식 복사'}</span>
              </button>
            </div>
          </div>

          {/* 4 Core Pillars of Afan Music Policy */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-6">
            <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800/80 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <Award className="w-4 h-4" />
                <span>공모전 출품작 전면 무료</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                공모전 상금 여부와 관계없이 자유롭게 사용 가능합니다.
                <span className="block text-amber-300/90 font-medium mt-1">
                  "더 나은 미래를 준비하시는 그 올바름은 당연히 응원받으셔야죠."
                </span>
              </p>
            </div>

            <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800/80 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                <Video className="w-4 h-4" />
                <span>개인 유튜브 수익창출 허용</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                소속사/기업형 채널이 아닌 개인 규모의 유튜브 채널이라면, <strong className="text-white">광고 수익이 창출되는 채널이라도 언제든 자유롭게</strong> BGM으로 사용하실 수 있습니다.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800/80 space-y-2">
              <div className="flex items-center gap-2 text-sky-400 font-bold text-sm">
                <Heart className="w-4 h-4" />
                <span>비상업적 용도 완전 개방</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                개인 소장, 학생 영상 과제, 포트폴리오, 독립 창작물 등 음원 자체를 재판매하는 행위가 아니라면 누구나 무료로 이용할 수 있습니다.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800/80 space-y-2">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                <ShieldCheck className="w-4 h-4" />
                <span>상업적 판매 및 납품 제한</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                음원 파일 자체의 유료 재판매, 특정 제작비를 수령한 방송/외주 납품, 원곡자 미표기 상업 공연은 사전 협의 및 정식 라이선스가 필요합니다.
              </p>
            </div>
          </div>

          <div className="mt-5 p-3.5 rounded-lg bg-zinc-900/95 border border-zinc-700/80 text-xs text-zinc-300 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>권장 출처 표기 양식:</strong> 영상 더보기란 또는 자막에 <code className="text-amber-300 bg-black/60 px-2 py-0.5 rounded font-mono">BGM: 아트판타지아 아판뮤직 (artfantasia.co.kr)</code>을 기재해 주시면 감사하겠습니다.
              </span>
            </div>
          </div>
        </div>

        {/* Filter Navigation */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <span className="text-xs font-mono text-amber-400 uppercase tracking-widest block mb-1">
              ORIGINAL TRACKS // {AFAN_TRACKS.length} SONGS
            </span>
            <h3 className="text-2xl font-black text-white">
              아판뮤직 오리지널 음원 라이브러리
            </h3>
          </div>

          {/* Genre Filter Pills */}
          <div className="flex flex-wrap gap-2">
            {genres.map((g) => (
              <button
                key={g}
                onClick={() => setSelectedGenre(g)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                  selectedGenre === g
                    ? 'bg-amber-400 text-black shadow-md font-bold'
                    : 'bg-zinc-900 text-zinc-300 hover:text-white border border-zinc-800 hover:border-zinc-600'
                }`}
              >
                {g === 'all' ? '전체 보기' : g}
              </button>
            ))}
          </div>
        </div>

        {/* Track List Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5 mb-14">
          {filteredTracks.map((track) => {
            const isPlaying = playingTrackId === track.id;
            const isCopied = copiedTrackId === track.id;

            return (
              <div
                key={track.id}
                className={`p-5 sm:p-6 rounded-2xl bg-zinc-950 border transition-all duration-300 flex flex-col justify-between ${
                  isPlaying
                    ? 'border-amber-400 shadow-xl shadow-amber-500/10 ring-1 ring-amber-400/30'
                    : 'border-zinc-800 hover:border-zinc-700 shadow-lg'
                }`}
              >
                <div>
                  {/* Top Bar: Genre & Duration & Featured Note */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-zinc-900 border border-zinc-800 text-amber-300">
                      {track.genre}
                    </span>
                    <div className="flex items-center gap-3 text-xs font-mono text-zinc-400">
                      <span>BPM {track.bpm}</span>
                      <span>·</span>
                      <span>{track.duration}</span>
                    </div>
                  </div>

                  {track.featuredNote && (
                    <div className="mb-2.5 inline-block text-[11px] font-bold text-amber-400 bg-amber-400/10 border border-amber-400/20 px-2.5 py-0.5 rounded">
                      {track.featuredNote}
                    </div>
                  )}

                  {/* Title & Artist */}
                  <h4 className="text-xl font-extrabold text-white hover:text-amber-300 transition-colors">
                    {track.title}
                  </h4>
                  <div className="text-xs font-semibold text-zinc-400 mt-0.5">
                    {track.mood}
                  </div>

                  {/* Description */}
                  <p className="text-xs text-zinc-300 leading-relaxed font-normal mt-2.5">
                    {track.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-3 mt-3 border-t border-zinc-900">
                    {track.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded bg-zinc-900/90 text-[10px] font-mono text-zinc-400"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom Control Actions */}
                <div className="pt-4 mt-4 border-t border-zinc-800/80 flex items-center justify-between">
                  {/* Play Audio Synthesis Engine Button */}
                  <button
                    onClick={() => handlePlayToggle(track)}
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      isPlaying
                        ? 'bg-amber-400 text-black shadow-md animate-pulse'
                        : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-700'
                    }`}
                  >
                    {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                    <span>{isPlaying ? '재생 중지' : '실시간 미리듣기'}</span>
                  </button>

                  {/* Copy YouTube Citation Button */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopyCitation(track.title, track.id)}
                      title="유튜브 더보기란 출처 복사"
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-xs font-medium text-zinc-300 hover:text-white transition-colors cursor-pointer"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-zinc-400" />}
                      <span>{isCopied ? '출처 복사됨' : '출처 복사'}</span>
                    </button>

                    <a
                      href="https://artfantasia.co.kr/category/%EC%95%84%ED%8C%90%EB%AE%A4%EC%A7%81%20*"
                      target="_blank"
                      rel="noreferrer"
                      title="블로그에서 음원 다운로드 및 감상하기"
                      className="p-2 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-300 hover:text-white transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-400" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Custom Music Production Inquiry CTA Banner */}
        <div className="p-8 sm:p-10 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden shadow-2xl">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-amber-400/10 border border-amber-400/20 text-xs font-mono text-amber-400 font-bold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>CUSTOM MUSIC & ORIGINAL SCORE</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white">
              브랜드만을 위한 독점 오리지널 음악이 필요하신가요?
            </h3>
            <p className="text-xs sm:text-sm text-zinc-400 max-w-xl">
              지상파 라디오 CM, 시그니처 로고송, 대형 영상 BGM, 영화/드라마 OST부터 Genelec 7.1.4 Dolby Atmos 마스터링까지 최고 수준의 음악을 전속 작곡가 팀이 맞춤 제작해 드립니다.
            </p>
          </div>

          <button
            onClick={onOpenInquiry}
            className="shrink-0 inline-flex items-center gap-2 px-7 py-3.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-sm shadow-xl transition-transform hover:scale-[1.02] cursor-pointer"
          >
            <Send className="w-4 h-4" />
            <span>음악 제작 문의하기</span>
          </button>
        </div>

      </div>
    </section>
  );
};
